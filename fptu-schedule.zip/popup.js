/** Tránh TypeError "reading 'local'" khi chrome.storage chưa có trong context. */
function getChromeStorageLocal() {
  try {
    if (typeof chrome === "undefined") return null;
    const stor = chrome.storage;
    if (!stor || stor.local == null) return null;
    return stor.local;
  } catch (_) {
    return null;
  }
}

function mirrorClassScheduleToStorage(jsonString) {
  const loc = getChromeStorageLocal();
  if (!loc) return;
  try {
    loc.set({ classSchedule: jsonString }, () => {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARMS" }).catch(() => {});
      }
    });
  } catch (_) {}
}

function mirrorExamScheduleToStorage(events) {
  const loc = getChromeStorageLocal();
  if (!loc) return;
  try {
    const json = typeof events === "string" ? events : JSON.stringify(events || []);
    loc.set({ examSchedule: json }, () => {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARMS" }).catch(() => {});
      }
    });
  } catch (_) {}
}

// Immediate theme detection to prevent flash of light theme
(function () {
  try {
    if (typeof window !== "undefined" && window.matchMedia && typeof document !== "undefined" && document.documentElement) {
      const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      document.documentElement.setAttribute("data-theme", systemPrefersDark ? "dark" : "light");
      document.documentElement.setAttribute("data-theme-preference", "auto");
    }
  } catch (_) {}
})();

// Apply the saved accent colour before first paint of the popup content (localStorage is synchronous).
(function () {
  try {
    if (typeof applyAccent === "function" && typeof localStorage !== "undefined") {
      applyAccent(document, localStorage.getItem("accentColor"));
    }
  } catch (_) {}
})();

// Schedule view mode state
let currentScheduleViewMode = "list";
try {
  const savedViewMode = localStorage.getItem("fptu_schedule_view_mode");
  if (savedViewMode === "week" || savedViewMode === "list") {
    currentScheduleViewMode = savedViewMode;
  }
} catch (_) {}
let currentWeekOffset = 0;
let lastRenderedClassSchedule = [];

document.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "WEEK_RANGE_PROGRESS") {
      setWeekRangeStatus(`Đang đồng bộ ${msg.current}/${msg.total}: ${msg.label}…`, true);
    }
    if (msg.type === "WEEK_RANGE_SYNC_DONE") {
      applyWeekRangeSyncDoneFromBackground(msg);
    }
    if (msg.type === "WEEK_RANGE_SYNC_ERROR" && msg.message === "login") {
      weekRangeSyncInProgress = false;
      setWeekRangeControlsDisabled(false);
      setWeekRangeStatus("", false);
      showError("Phiên đăng nhập hết hạn. Đăng nhập lại FAP rồi thử đồng bộ khoảng tuần.");
    }
    if (msg.type === "ALL_GRADES_SYNC_DONE") {
      showToast(`Đã quét xong ${msg.savedCount || 0}/${msg.total || 0} môn!`);
      loadAndRenderStudentGrades();
    }
  });

  const stInit = getChromeStorageLocal();
  if (stInit) {
    try {
      stInit.get(["weekRangeSyncRunning"], (r) => {
        if (chrome.runtime.lastError) return;
        if (r.weekRangeSyncRunning) {
          weekRangeSyncInProgress = true;
          const weekRangeModal = document.getElementById("weekRangeModal");
          if (weekRangeModal) weekRangeModal.style.display = "block";
          setWeekRangeControlsDisabled(true);
          setWeekRangeStatus("Đồng bộ nhiều tuần vẫn đang chạy…", true);
          pollWeekRangeSyncUntilIdle();
        }
      });
    } catch (_) { /* no storage API */ }
  }

  const syncButton = document.getElementById("syncButton");
  const exportBtn = document.getElementById("exportBtn");
  const settingsButton = document.getElementById("settingsButton");
  const filterModal = document.getElementById("filterModal");
  const closeFilter = document.getElementById("closeFilter");
  const docsLink = document.getElementById("docsLink");
  const privacyLink = document.getElementById("privacyLink");
  const authorLink = document.getElementById("authorLink");
  
  // Notification settings modal elements
  const notificationBtn = document.getElementById("notificationBtn");
  const notificationModal = document.getElementById("notificationModal");
  const closeNotificationModal = document.getElementById("closeNotificationModal");
  const notifMasterToggle = document.getElementById("notifMasterToggle");
  const notifClassEnabled = document.getElementById("notifClassEnabled");
  const notifClass15 = document.getElementById("notifClass15");
  const notifClass30 = document.getElementById("notifClass30");
  const notifExamEnabled = document.getElementById("notifExamEnabled");
  const notifExam1Day = document.getElementById("notifExam1Day");
  const notifExam1Hour = document.getElementById("notifExam1Hour");
  const testNotificationBtn = document.getElementById("testNotificationBtn");
  const notifChangesEnabled = document.getElementById("notifChangesEnabled");
  const notifBadgeEnabled = document.getElementById("notifBadgeEnabled");
  const notifStatus = document.getElementById("notifStatus");
  const saveNotificationBtn = document.getElementById("saveNotificationBtn");
  const fapKeepSessionToggle = document.getElementById("fapKeepSessionToggle");
  const fapUiToggle = document.getElementById("fapUiToggle");

  const DEFAULT_SETTINGS = (typeof DEFAULT_NOTIFICATION_SETTINGS !== "undefined")
    ? DEFAULT_NOTIFICATION_SETTINGS
    : {
        enabled: true,
        class: { enabled: true, offset15: true, offset30: false },
        exam: { enabled: true, offset1Day: true, offset1Hour: true },
        changes: { enabled: true },
        badge: { enabled: true }
      };

  function updateNotificationButtonState(enabled) {
    if (notificationBtn) {
      notificationBtn.classList.toggle("is-active", !!enabled);
    }
  }

  function syncNotificationForm(settings) {
    const s = settings || DEFAULT_SETTINGS;
    if (notifMasterToggle) notifMasterToggle.checked = !!s.enabled;
    if (notifClassEnabled) notifClassEnabled.checked = !!(s.class && s.class.enabled);
    if (notifClass15) notifClass15.checked = !!(s.class && s.class.offset15);
    if (notifClass30) notifClass30.checked = !!(s.class && s.class.offset30);
    if (notifExamEnabled) notifExamEnabled.checked = !!(s.exam && s.exam.enabled);
    if (notifExam1Day) notifExam1Day.checked = !!(s.exam && s.exam.offset1Day);
    if (notifExam1Hour) notifExam1Hour.checked = !!(s.exam && s.exam.offset1Hour);
    // Settings saved before this option existed have no "changes" key: treat that as on.
    if (notifChangesEnabled) notifChangesEnabled.checked = !(s.changes && s.changes.enabled === false);
    if (notifBadgeEnabled) notifBadgeEnabled.checked = !(s.badge && s.badge.enabled === false);
    updateNotificationButtonState(s.enabled);
  }

  const locStorage = getChromeStorageLocal();
  if (locStorage) {
    locStorage.get(["notificationSettings", "fapKeepSessionEnabled", "fapUiEnabled"], (res) => {
      syncNotificationForm(res && res.notificationSettings);
      if (fapKeepSessionToggle && res && res.fapKeepSessionEnabled !== undefined) {
        fapKeepSessionToggle.checked = res.fapKeepSessionEnabled !== false;
      }
      if (fapUiToggle) {
        fapUiToggle.checked = !res || res.fapUiEnabled !== false;
      }
    });
  }

  // Accent colour picker: applies and saves immediately, no Save button needed.
  const accentPicker = document.getElementById("accentPicker");
  function currentAccentId() {
    try {
      return normalizeAccentId(localStorage.getItem("accentColor"));
    } catch (_) {
      return DEFAULT_ACCENT_ID;
    }
  }
  function renderAccentPicker() {
    if (!accentPicker || typeof ACCENT_PRESETS === "undefined") return;
    const active = currentAccentId();
    accentPicker.textContent = "";
    ACCENT_PRESETS.forEach((preset) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "accent-swatch";
      btn.dataset.accent = preset.id;
      btn.title = preset.label;
      btn.setAttribute("role", "radio");
      btn.setAttribute("aria-label", preset.label);
      btn.setAttribute("aria-checked", preset.id === active ? "true" : "false");
      btn.style.setProperty("--swatch-light", preset.light);
      btn.style.setProperty("--swatch-dark", preset.dark);
      btn.addEventListener("click", () => {
        try {
          localStorage.setItem("accentColor", preset.id);
        } catch (_) {}
        if (locStorage) {
          try {
            locStorage.set({ accentColor: preset.id });
          } catch (_) {}
        }
        applyAccent(document, preset.id);
        accentPicker.querySelectorAll(".accent-swatch").forEach((el) => {
          el.setAttribute("aria-checked", el === btn ? "true" : "false");
        });
      });
      accentPicker.appendChild(btn);
    });
  }
  renderAccentPicker();
  if (locStorage) {
    try {
      locStorage.get(["accentColor"], (res) => {
        if (!res || !res.accentColor) {
          try {
            const stored = localStorage.getItem("accentColor");
            if (stored) {
              locStorage.set({ accentColor: stored });
            }
          } catch (_) {}
        }
      });
    } catch (_) {}
  }

  // Theme management
  const themeToggleBtn = document.getElementById("themeToggleBtn");
  let currentThemePreference = "auto";

  function applyTheme(preference, showToastFeedback = false) {
    currentThemePreference = preference || "auto";
    const systemPrefersDark = !!(
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: dark)").matches
    );
    const effectiveTheme = (typeof resolveEffectiveTheme === "function")
      ? resolveEffectiveTheme(currentThemePreference, systemPrefersDark)
      : (currentThemePreference === "dark" || (currentThemePreference === "auto" && systemPrefersDark) ? "dark" : "light");

    if (typeof document !== "undefined" && document.documentElement) {
      document.documentElement.setAttribute("data-theme", effectiveTheme);
      document.documentElement.setAttribute("data-theme-preference", currentThemePreference);
    }

    if (themeToggleBtn) {
      const iconName = (typeof getThemeIcon === "function") ? getThemeIcon(currentThemePreference) : "icon-theme-auto";
      const label = (typeof getThemeLabel === "function") ? getThemeLabel(currentThemePreference) : "Chế độ giao diện";
      themeToggleBtn.setAttribute("title", label);
      themeToggleBtn.setAttribute("aria-label", label);
      const useEl = themeToggleBtn.querySelector("use");
      if (useEl) {
        useEl.setAttribute("href", `#${iconName}`);
      }
    }

    if (showToastFeedback && typeof showToast === "function") {
      const label = (typeof getThemeLabel === "function") ? getThemeLabel(currentThemePreference) : "Chế độ giao diện";
      showToast(label);
    }
  }

  if (locStorage) {
    locStorage.get(["theme"], (res) => {
      applyTheme(res && res.theme ? res.theme : "auto", false);
    });
  } else {
    applyTheme("auto", false);
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", () => {
      const nextTheme = (typeof getNextTheme === "function")
        ? getNextTheme(currentThemePreference)
        : (currentThemePreference === "auto" ? "light" : currentThemePreference === "light" ? "dark" : "auto");
      const storage = getChromeStorageLocal();
      if (storage) {
        storage.set({ theme: nextTheme }, () => {
          applyTheme(nextTheme, true);
        });
      } else {
        applyTheme(nextTheme, true);
      }
    });
  }

  if (typeof window !== "undefined" && window.matchMedia) {
    const colorSchemeMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleMediaChange = () => {
      if (currentThemePreference === "auto") {
        applyTheme("auto", false);
      }
    };
    if (typeof colorSchemeMediaQuery.addEventListener === "function") {
      colorSchemeMediaQuery.addEventListener("change", handleMediaChange);
    } else if (typeof colorSchemeMediaQuery.addListener === "function") {
      colorSchemeMediaQuery.addListener(handleMediaChange);
    }
  }

  function refreshNotificationStatus() {
    if (!notifStatus) return;
    notifStatus.textContent = "";
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) return;
    try {
      chrome.runtime.sendMessage({ type: "GET_ALARM_SUMMARY" }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        if (!res.count) {
          notifStatus.textContent = "Chưa có nhắc nhở nào được đặt. Hãy đồng bộ lịch học hoặc lịch thi.";
          return;
        }
        const when = res.nextTime
          ? new Date(res.nextTime).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "numeric" })
          : "";
        notifStatus.textContent = `Đã đặt ${res.count} nhắc nhở${when ? `, gần nhất lúc ${when}` : ""}.`;
      });
    } catch (_) {}
  }

  if (notificationBtn && notificationModal) {
    notificationBtn.addEventListener("click", () => {
      if (locStorage) {
        locStorage.get(["notificationSettings", "fapKeepSessionEnabled", "fapUiEnabled"], (res) => {
          syncNotificationForm(res && res.notificationSettings);
          if (fapKeepSessionToggle) {
            fapKeepSessionToggle.checked = res && res.fapKeepSessionEnabled !== false;
          }
          if (fapUiToggle) {
            fapUiToggle.checked = res && res.fapUiEnabled !== false;
          }
          notificationModal.style.display = "block";
          refreshNotificationStatus();
        });
      } else {
        notificationModal.style.display = "block";
      }
    });
  }

  if (fapKeepSessionToggle) {
    fapKeepSessionToggle.addEventListener("change", () => {
      if (locStorage) {
        locStorage.set({ fapKeepSessionEnabled: fapKeepSessionToggle.checked });
      }
    });
  }

  if (fapUiToggle) {
    fapUiToggle.addEventListener("change", () => {
      if (locStorage) {
        locStorage.set({ fapUiEnabled: fapUiToggle.checked });
      }
    });
  }

  if (closeNotificationModal && notificationModal) {
    closeNotificationModal.addEventListener("click", () => {
      notificationModal.style.display = "none";
    });
  }

  if (testNotificationBtn) {
    testNotificationBtn.addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: "TEST_NOTIFICATION" }, (res) => {
          if (chrome.runtime.lastError || !res) {
            showError("Không gửi được thông báo thử. Hãy tải lại extension rồi thử lại.");
          } else if (res.ok) {
            showToast("Đã gửi thông báo thử nghiệm! Nếu không thấy gì, hãy kiểm tra cài đặt thông báo của hệ điều hành.");
          } else if (res.reason === "denied") {
            showError("Thông báo của Chrome đang bị tắt. Bật lại trong cài đặt thông báo của hệ điều hành hoặc Chrome.");
          } else {
            showError(`Không gửi được thông báo thử${res.message ? `: ${res.message}` : "."}`);
          }
        });
      } else {
        showToast("Đã gửi thông báo thử nghiệm!");
      }
    });
  }

  if (saveNotificationBtn && notificationModal) {
    saveNotificationBtn.addEventListener("click", () => {
      const current = {
        enabled: notifMasterToggle ? notifMasterToggle.checked : true,
        class: {
          enabled: notifClassEnabled ? notifClassEnabled.checked : true,
          offset15: notifClass15 ? notifClass15.checked : true,
          offset30: notifClass30 ? notifClass30.checked : false
        },
        exam: {
          enabled: notifExamEnabled ? notifExamEnabled.checked : true,
          offset1Day: notifExam1Day ? notifExam1Day.checked : true,
          offset1Hour: notifExam1Hour ? notifExam1Hour.checked : true
        },
        changes: {
          enabled: notifChangesEnabled ? notifChangesEnabled.checked : true
        },
        badge: {
          enabled: notifBadgeEnabled ? notifBadgeEnabled.checked : true
        }
      };

      const fapKeepSessionEnabled = fapKeepSessionToggle ? fapKeepSessionToggle.checked : true;
      const fapUiEnabled = fapUiToggle ? fapUiToggle.checked : true;

      if (locStorage) {
        locStorage.set({ notificationSettings: current, fapKeepSessionEnabled, fapUiEnabled }, () => {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARMS" }).catch(() => {});
          }
          updateNotificationButtonState(current.enabled);
          notificationModal.style.display = "none";
          showToast("Đã lưu cài đặt!");
        });
      } else {
        updateNotificationButtonState(current.enabled);
        notificationModal.style.display = "none";
        showToast("Đã lưu cài đặt!");
      }
    });
  }

  // QR / Export Modal elements & event handlers
  const qrExamBtn = document.getElementById("qrExamBtn");
  const qrScheduleBtn = document.getElementById("qrScheduleBtn");
  const qrSyncModal = document.getElementById("qrSyncModal");
  const qrSyncTitle = document.getElementById("qrSyncTitle");
  const closeQrSyncModal = document.getElementById("closeQrSyncModal");
  const qrScopeContainer = document.getElementById("qrScopeContainer");
  const qrMetaInfo = document.getElementById("qrMetaInfo");
  const qrDisplayCard = document.getElementById("qrDisplayCard");
  const copyIcalPayloadBtn = document.getElementById("copyIcalPayloadBtn");
  const modalDownloadIcsBtn = document.getElementById("modalDownloadIcsBtn");
  const qrInstructions = document.getElementById("qrInstructions");

  let currentQrMode = "schedule";
  let currentQrScope = "week";
  let currentQrPayload = "";

  function handleDownloadExamSchedule() {
    const storedData = localStorage.getItem("examSchedule");
    if (!storedData) {
      showError("Chưa có dữ liệu lịch thi. Mở trang lịch thi FAP rồi nhấn «Đồng bộ lịch thi».");
      return;
    }

    let events;
    try {
      events = JSON.parse(storedData);
    } catch (e) {
      console.error("Parse stored data failed:", e);
      showError("Dữ liệu lịch thi bị lỗi. Đồng bộ lại từ trang FAP.");
      return;
    }

    if (!events || !events.length) {
      showError("Không có lịch thi nào để xuất.");
      return;
    }

    const cal = createExamCalendar();
    let validEventsCount = 0;
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    events.forEach((e) => {
      const start = new Date(e.start);
      const examDate = new Date(start.getFullYear(), start.getMonth(), start.getDate());
      const diffTime = examDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays < 0) return;

      if (
        !e.location ||
        e.location.trim() === "" ||
        e.location.toLowerCase().includes("chưa có") ||
        e.location.toLowerCase().includes("chưa rõ") ||
        e.location.toLowerCase() === "tba" ||
        e.location.toLowerCase() === "to be announced"
      ) {
        return;
      }

      let title = e.title;
      if (e.tag) {
        title += " - " + e.tag;
      } else {
        if (/2nd_fe/i.test(e.description)) title += " - 2NDFE";
        else if (/practical_exam/i.test(e.description)) title += " - PE";
        else if (/multiple_choices|final|fe/i.test(e.description)) title += " - FE";
      }

      cal.addEvent(title, e.description, e.location, new Date(e.start), new Date(e.end));
      validEventsCount++;
    });

    if (validEventsCount === 0) {
      showError("Không có kỳ thi sắp tới đã có phòng để xuất ra .ics.");
      return;
    }

    const blob = new Blob([cal.build()], { type: "text/calendar" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.setAttribute("href", url);
    a.setAttribute("download", "lich-thi.ics");
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  }

  function updateQrSyncModal() {
    if (!qrDisplayCard) return;

    if (qrSyncTitle) {
      qrSyncTitle.textContent = currentQrMode === "exam" ? "Xuất lịch thi" : "Xuất lịch học";
    }

    if (currentQrMode === "exam") {
      if (qrScopeContainer) qrScopeContainer.style.display = "none";
      let examEvents = [];
      try {
        const raw = localStorage.getItem("examSchedule");
        if (raw) examEvents = JSON.parse(raw);
      } catch (_) {}

      if (typeof buildQrCalendarPayload === "function") {
        currentQrPayload = buildQrCalendarPayload({ type: "exam", events: examEvents, now: new Date(), maxEvents: 16 });
      } else {
        currentQrPayload = "";
      }

      if (!currentQrPayload) {
        if (qrMetaInfo) qrMetaInfo.textContent = "Không có kỳ thi sắp tới có phòng";
        qrDisplayCard.innerHTML = '<div class="qr-empty-msg">Chưa có lịch thi sắp tới đã có phòng để tạo mã QR. Hãy đồng bộ từ FAP trước.</div>';
        if (qrInstructions) qrInstructions.textContent = "Quét bằng Camera điện thoại hoặc tải file .ics về máy tính.";
        if (copyIcalPayloadBtn) copyIcalPayloadBtn.disabled = true;
        if (modalDownloadIcsBtn) modalDownloadIcsBtn.disabled = true;
      } else {
        const count = (currentQrPayload.match(/BEGIN:VEVENT/g) || []).length;
        if (qrMetaInfo) qrMetaInfo.textContent = `Tất cả môn thi sắp tới (${count} môn)`;
        if (qrInstructions) qrInstructions.textContent = "Quét bằng Camera điện thoại để thêm vào Lịch, hoặc tải file .ics về máy.";
        if (typeof QRCode !== "undefined" && QRCode.toSvgString) {
          qrDisplayCard.innerHTML = QRCode.toSvgString(currentQrPayload, { size: 164, margin: 4, ecLevel: "L" });
        }
        if (copyIcalPayloadBtn) copyIcalPayloadBtn.disabled = false;
        if (modalDownloadIcsBtn) modalDownloadIcsBtn.disabled = false;
      }
    } else {
      // schedule mode
      if (qrScopeContainer) {
        qrScopeContainer.style.display = "flex";
        const buttons = qrScopeContainer.querySelectorAll(".qr-scope-btn");
        buttons.forEach((btn) => {
          btn.classList.toggle("active", btn.dataset.scope === currentQrScope);
        });
      }

      let classSchedule = [];
      try {
        const raw = localStorage.getItem("classSchedule");
        if (raw) classSchedule = JSON.parse(raw);
      } catch (_) {}

      const scopeLabels = {
        today: "hôm nay",
        week: "tuần này",
        next_week: "tuần tới",
        "2weeks": "2 tuần tới",
        all: "tất cả"
      };
      const scopeDisplayLabels = {
        today: "Hôm nay",
        week: "Tuần này",
        next_week: "Tuần tới",
        "2weeks": "2 tuần tới",
        all: "Tất cả"
      };
      const label = scopeDisplayLabels[currentQrScope] || currentQrScope;

      let fullPayload = "";
      if (typeof buildQrCalendarPayload === "function") {
        fullPayload = buildQrCalendarPayload({
          type: "schedule",
          events: classSchedule,
          scope: currentQrScope,
          now: new Date(),
          maxEvents: 0
        });
        currentQrPayload = buildQrCalendarPayload({
          type: "schedule",
          events: classSchedule,
          scope: currentQrScope,
          now: new Date(),
          maxEvents: 16
        });
      } else {
        currentQrPayload = "";
      }

      if (!currentQrPayload) {
        const lowerLabel = scopeLabels[currentQrScope] || currentQrScope;
        if (qrMetaInfo) qrMetaInfo.textContent = `Không có tiết học ${lowerLabel}`;
        qrDisplayCard.innerHTML = `<div class="qr-empty-msg">Không có tiết học nào trong <strong>${lowerLabel}</strong> để tạo mã QR.</div>`;
        if (qrInstructions) qrInstructions.textContent = "Quét bằng Camera điện thoại hoặc tải file .ics về máy tính.";
        if (copyIcalPayloadBtn) copyIcalPayloadBtn.disabled = true;
        if (modalDownloadIcsBtn) modalDownloadIcsBtn.disabled = true;
      } else {
        const count = (currentQrPayload.match(/BEGIN:VEVENT/g) || []).length;
        const totalCount = (fullPayload.match(/BEGIN:VEVENT/g) || []).length;

        if (totalCount > count) {
          if (qrMetaInfo) qrMetaInfo.textContent = `Lịch học ${label}: ${count}/${totalCount} buổi (16 buổi sắp tới)`;
          if (qrInstructions) {
            qrInstructions.textContent = `Mã QR chứa 16 buổi gần nhất. Tải file .ics bên dưới để thêm toàn bộ ${totalCount} buổi cả kỳ vào điện thoại!`;
          }
        } else {
          if (qrMetaInfo) qrMetaInfo.textContent = `Lịch học ${label}: ${count} buổi`;
          if (qrInstructions) {
            qrInstructions.textContent = "Quét bằng Camera điện thoại hoặc tải file .ics về máy tính.";
          }
        }

        if (typeof QRCode !== "undefined" && QRCode.toSvgString) {
          qrDisplayCard.innerHTML = QRCode.toSvgString(currentQrPayload, { size: 164, margin: 4, ecLevel: "L" });
        }
        if (copyIcalPayloadBtn) copyIcalPayloadBtn.disabled = false;
        if (modalDownloadIcsBtn) modalDownloadIcsBtn.disabled = false;
      }
    }
  }

  function openQrSyncModal(mode) {
    currentQrMode = mode;
    if (mode === "schedule") currentQrScope = "week";
    if (qrSyncModal) qrSyncModal.style.display = "block";
    updateQrSyncModal();
  }

  function closeQrSyncModalFunc() {
    if (qrSyncModal) qrSyncModal.style.display = "none";
  }

  if (qrExamBtn) {
    qrExamBtn.addEventListener("click", () => openQrSyncModal("exam"));
  }

  if (qrScheduleBtn) {
    qrScheduleBtn.addEventListener("click", () => openQrSyncModal("schedule"));
  }

  if (closeQrSyncModal) {
    closeQrSyncModal.addEventListener("click", closeQrSyncModalFunc);
  }

  if (qrScopeContainer) {
    const scopeBtns = qrScopeContainer.querySelectorAll(".qr-scope-btn");
    scopeBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        currentQrScope = btn.dataset.scope;
        updateQrSyncModal();
      });
    });
  }

  if (copyIcalPayloadBtn) {
    copyIcalPayloadBtn.addEventListener("click", () => {
      if (!currentQrPayload) return;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(currentQrPayload).then(() => {
          showToast("Đã sao chép nội dung iCal!");
        }).catch(() => {
          showToast("Không thể sao chép vào clipboard.");
        });
      } else {
        showToast("Đã sao chép nội dung iCal!");
      }
    });
  }

  if (modalDownloadIcsBtn) {
    modalDownloadIcsBtn.addEventListener("click", () => {
      if (currentQrMode === "exam") {
        handleDownloadExamSchedule();
      } else {
        handleDownloadClassSchedule();
      }
    });
  }

  window.addEventListener("click", (e) => {
    if (e.target === qrSyncModal) {
      closeQrSyncModalFunc();
    }
  });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && qrSyncModal && qrSyncModal.style.display === "block") {
      closeQrSyncModalFunc();
    }
  });

  window.openQrSyncModal = openQrSyncModal;
  window.updateQrSyncModal = updateQrSyncModal;
  window.closeQrSyncModal = closeQrSyncModalFunc;
  window.handleDownloadClassSchedule = handleDownloadClassSchedule;
  window.handleDownloadExamSchedule = handleDownloadExamSchedule;
  window.handleClearExamSchedule = handleClearExamSchedule;
  window.deleteSingleExam = deleteSingleExam;

  
  // Tab switching functionality - add this right after the other element declarations
  const upcomingTab = document.getElementById("upcomingTab");
  const upcomingContent = document.getElementById("upcomingExams");
  const completedContent = document.getElementById("completedExams");
  const scheduleTabBtn = document.getElementById("scheduleTabBtn");
  const scheduleContent = document.getElementById("scheduleTab");
  const gradesTabBtn = document.getElementById("gradesTabBtn");
  const gradesContent = document.getElementById("gradesTab");
  const examActionsRow = document.getElementById("examActions");
  const scheduleActionsRow = document.getElementById("scheduleActions");
  const gradeActionsRow = document.getElementById("gradeActions");
  const examListSection = document.getElementById("examList");
  if (examActionsRow) examActionsRow.hidden = true;
  if (scheduleActionsRow) scheduleActionsRow.hidden = false;
  if (gradeActionsRow) gradeActionsRow.hidden = true;

  if (upcomingContent && completedContent) {
    const activateTab = (name) => {
      [upcomingTab, scheduleTabBtn, gradesTabBtn].forEach(btn => btn && btn.classList.remove("active"));
      [upcomingContent, completedContent, scheduleContent, gradesContent].forEach(c => c && c.classList.remove("active"));

      const examAct = document.getElementById("examActions");
      const schedAct = document.getElementById("scheduleActions");
      const gradeAct = document.getElementById("gradeActions");
      if (examAct) examAct.hidden = (name !== "exams");
      if (schedAct) schedAct.hidden = (name !== "schedule");
      if (gradeAct) gradeAct.hidden = (name !== "grades");

      if (name === "schedule") {
        if (scheduleTabBtn) {
          scheduleTabBtn.classList.add("active");
          scheduleTabBtn.setAttribute("aria-selected", "true");
        }
        if (upcomingTab) upcomingTab.setAttribute("aria-selected", "false");
        if (gradesTabBtn) gradesTabBtn.setAttribute("aria-selected", "false");
        if (scheduleContent) scheduleContent.classList.add("active");
        if (examListSection) examListSection.classList.remove("exams-two-col");
        const syncLoad = document.getElementById("examSyncLoading");
        const syncErr = document.getElementById("examSyncError");
        if (syncLoad) syncLoad.hidden = true;
        if (syncErr) syncErr.hidden = true;
      } else if (name === "exams") {
        if (upcomingTab) {
          upcomingTab.classList.add("active");
          upcomingTab.setAttribute("aria-selected", "true");
        }
        if (scheduleTabBtn) scheduleTabBtn.setAttribute("aria-selected", "false");
        if (gradesTabBtn) gradesTabBtn.setAttribute("aria-selected", "false");
        upcomingContent.classList.add("active");
        completedContent.classList.add("active");
        if (examListSection) examListSection.classList.add("exams-two-col");
      } else if (name === "grades") {
        if (gradesTabBtn) {
          gradesTabBtn.classList.add("active");
          gradesTabBtn.setAttribute("aria-selected", "true");
        }
        if (scheduleTabBtn) scheduleTabBtn.setAttribute("aria-selected", "false");
        if (upcomingTab) upcomingTab.setAttribute("aria-selected", "false");
        if (gradesContent) gradesContent.classList.add("active");
        if (examListSection) examListSection.classList.remove("exams-two-col");
        loadAndRenderStudentGrades();
      }
    };

    if (upcomingTab) upcomingTab.addEventListener("click", () => activateTab("exams"));
    if (scheduleTabBtn) scheduleTabBtn.addEventListener("click", () => activateTab("schedule"));
    if (gradesTabBtn) gradesTabBtn.addEventListener("click", () => activateTab("grades"));

    // The tab bar is position:sticky; drop a shadow on it only once content
    // is actually scrolling underneath, so it stays flat at rest.
    const tabBar = document.querySelector(".tab-bar");
    let syncStuck = () => {};
    if (tabBar && examListSection) {
      syncStuck = () => {
        const isScrolling = examListSection.scrollTop > 0;
        tabBar.classList.toggle("is-stuck", isScrolling);
        const hasStickyBanner = !!document.querySelector("#scheduleTab.active .agenda-banner");
        tabBar.classList.toggle("no-shadow", isScrolling && hasStickyBanner);
      };
      examListSection.addEventListener("scroll", syncStuck, { passive: true });
      syncStuck();
    }

    // Mặc định: Lịch học (khớp tab active trên HTML)
    activateTab("schedule");
    syncStuck();
  }

  // Load filter preferences
  let filterPrefs = { FE: true, PE: true, "2NDFE": true, "2NDPE": true };
  try {
    filterPrefs = JSON.parse(
      localStorage.getItem("examFilter") || '{"FE":true,"PE":true,"2NDFE":true,"2NDPE":true}'
    );
  } catch (_) {
    /* keep defaults */
  }
  
  // Set initial filter states
  if (document.getElementById("filterFE")) {
    document.getElementById("filterFE").checked = filterPrefs.FE;
    document.getElementById("filterPE").checked = filterPrefs.PE;
    document.getElementById("filter2NDFE").checked = filterPrefs["2NDFE"];
    document.getElementById("filter2NDPE").checked = filterPrefs["2NDPE"];
  }

  // Filter modal events
  if (settingsButton && filterModal) {
    settingsButton.addEventListener("click", () => {
      filterModal.style.display = "block";
    });
  }

  if (closeFilter && filterModal) {
    closeFilter.addEventListener("click", () => {
      filterModal.style.display = "none";
    });
  }

  // Close modal when clicking outside
  if (filterModal) {
    filterModal.addEventListener("click", (e) => {
      if (e.target === filterModal) {
        filterModal.style.display = "none";
      }
    });
  }

  // Remove the immediate filter change events - comment them out completely
  // ["filterFE", "filterPE", "filter2NDFE", "filter2NDPE"].forEach(id => {
  //   const element = document.getElementById(id);
  //   if (element) {
  //     element.addEventListener("change", () => {
  //       saveFilterPrefs();
  //       applyFilters();
  //     });
  //   }
  // });

  // Select/Deselect all buttons
  const selectAllBtn = document.getElementById("selectAll");
  const deselectAllBtn = document.getElementById("deselectAll");
  const applyFilterBtn = document.getElementById("applyFilter");
  
  if (selectAllBtn) {
    selectAllBtn.addEventListener("click", () => {
      ["filterFE", "filterPE", "filter2NDFE", "filter2NDPE"].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.checked = true;
      });
    });
  }

  if (deselectAllBtn) {
    deselectAllBtn.addEventListener("click", () => {
      ["filterFE", "filterPE", "filter2NDFE", "filter2NDPE"].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.checked = false;
      });
    });
  }

  if (applyFilterBtn) {
    applyFilterBtn.addEventListener("click", () => {
      saveFilterPrefs();
      applyFilters();
      filterModal.style.display = "none";
    });
  }

  function saveFilterPrefs() {
    const prefs = {
      FE: document.getElementById("filterFE")?.checked || false,
      PE: document.getElementById("filterPE")?.checked || false,
      "2NDFE": document.getElementById("filter2NDFE")?.checked || false,
      "2NDPE": document.getElementById("filter2NDPE")?.checked || false
    };
    localStorage.setItem("examFilter", JSON.stringify(prefs));
  }

  function applyFilters() {
    const upcomingItems = document.querySelectorAll("#upcomingExams .exam-item");
    const completedItems = document.querySelectorAll("#completedExams .exam-item");
    const activeFilters = JSON.parse(localStorage.getItem("examFilter") || '{"FE":true,"PE":true,"2NDFE":true,"2NDPE":true}');
    
    // Apply filters to both upcoming and completed tabs
    [...upcomingItems, ...completedItems].forEach(item => {
      const examCard = item.querySelector(".exam-card");
      const tags = examCard.querySelectorAll(".tag");
      let examType = null;
      
      // Check for exam type tags
      tags.forEach(tag => {
        if (tag.classList.contains("fe")) examType = "FE";
        else if (tag.classList.contains("pe")) examType = "PE";
        else if (tag.classList.contains("secondfe")) examType = "2NDFE";
        else if (tag.classList.contains("secondpe")) examType = "2NDPE";
      });
      
      // If no specific exam type found, try to determine from tag text
      if (!examType) {
        tags.forEach(tag => {
          const tagText = tag.textContent.trim();
          if (tagText === "FE") examType = "FE";
          else if (tagText === "PE") examType = "PE";
          else if (tagText === "2NDFE") examType = "2NDFE";
          else if (tagText === "2NDPE") examType = "2NDPE";
        });
      }
      
      // Show if no exam type found or if exam type is enabled
      if (!examType || activeFilters[examType]) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });
  }

  window.applyFilters = applyFilters;

  if (syncButton) {
    syncButton.addEventListener("click", () => {
      chrome.tabs.query({ url: "*://fap.fpt.edu.vn/*" }, (tabs) => {
        const examTab = (tabs || []).find((t) => t.url && (/ExamSchedule/i.test(t.url) || /ScheduleExams/i.test(t.url)));
        if (examTab && examTab.id) {
          chrome.tabs.update(examTab.id, { active: true });
        } else {
          chrome.tabs.create({ url: "https://fap.fpt.edu.vn/ExamSchedule", active: true });
        }
      });
    });
  }

  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      openQrSyncModal("exam");
    });
  }

  const clearExamBtn = document.getElementById("clearExamBtn");
  if (clearExamBtn) {
    clearExamBtn.addEventListener("click", handleClearExamSchedule);
  }


  setTimeout(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs && tabs[0] && tabs[0].url && (/ExamSchedule/i.test(tabs[0].url) || /ScheduleExams/i.test(tabs[0].url))) {
        autoSyncSchedule();
      }
    });
  }, 100);

  const data = localStorage.getItem("examSchedule");
  if (data) {
    try {
      renderExamList(JSON.parse(data));
    } catch (e) {
      console.error("Parse failed:", e);
    }
  } else {
    const up = document.getElementById("upcomingExams");
    const co = document.getElementById("completedExams");
    if (up && co) {
      while (up.firstChild) up.removeChild(up.firstChild);
      while (co.firstChild) co.removeChild(co.firstChild);
      const hint = document.createElement("div");
      hint.className = "exam-list-hint";
      hint.textContent = "Chưa có dữ liệu lịch thi. Nhấn «Đồng bộ lịch thi» để mở FAP và tải lịch.";
      up.appendChild(hint);
    }
  }

  // Load class schedule for the new tab
  const storedSchedule = localStorage.getItem("classSchedule");
  if (storedSchedule) {
    try {
      renderClassSchedule(JSON.parse(storedSchedule));
    } catch (e) {
      console.error("Parse stored class schedule failed:", e);
    }
  } else {
    // Ensure empty state appears if container exists
    const sc = document.getElementById("scheduleTab");
    if (sc && !sc.firstChild) {
      const empty = document.createElement("div");
      empty.className = "schedule-empty";
      empty.textContent = "Chưa có lịch học. Nhấn \"Sync lịch học\" để tải.";
      sc.appendChild(empty);
    }
  }
  // Try to auto-refresh attendance status from the current FAP page (only updates matching items)
  tryAutoRefreshAttendance();
  loadAndRenderStudentGrades();

function renderStudentGrades(gradesMap) {
  const container = document.getElementById("gradesTab");
  if (!container) return;

  container.innerHTML = "";

  const courses = Object.values(gradesMap || {});

  // Update tab label with count
  const btn = document.getElementById("gradesTabBtn");
  const tabText = btn?.querySelector(".tab-btn__text");
  if (tabText) {
    tabText.textContent = courses.length ? `Điểm số (${courses.length})` : "Điểm số";
  }

  if (courses.length === 0) {
    const empty = document.createElement("div");
    empty.className = "schedule-empty";
    empty.innerHTML = `
      <p style="font-weight:650; font-size:14px; margin:0 0 6px;">Chưa có dữ liệu bảng điểm</p>
      <p style="font-size:12px; color:var(--text-muted); margin:0 0 14px; line-height:1.4;">
        Mở trang Điểm số FAP (StudentGrade) rồi nhấn <strong>«Đồng bộ»</strong> hoặc <strong>«Quét tất cả môn»</strong>.
      </p>
      <a href="https://fap.fpt.edu.vn/Grade/StudentGrade.aspx" target="_blank" class="action-btn action-btn--secondary" style="display:inline-flex; align-items:center; gap:6px; margin:0 auto; text-decoration:none; width:fit-content;">
        <svg class="icon" aria-hidden="true" style="width:14px; height:14px;"><use href="#icon-award"/></svg>
        <span>Mở FAP StudentGrade</span>
      </a>
    `;
    container.appendChild(empty);
    return;
  }

  // Sort courses alphabetically by courseCode
  courses.sort((a, b) => (a.courseCode || "").localeCompare(b.courseCode || ""));

  const list = document.createElement("div");
  list.className = "grades-list";

  courses.forEach((course) => {
    const card = document.createElement("div");
    card.className = "grade-card";

    const categories = course.categories || [];
    const bonus = Number(course.bonus) || 0;
    const { currentWeightedScore, completedWeight, remainingWeight } =
      typeof calculateCurrentScore === "function"
        ? calculateCurrentScore(categories, bonus)
        : { currentWeightedScore: 0, completedWeight: 0, remainingWeight: 100 };

    const isPassed = course.status === "Passed" || (remainingWeight === 0 && currentWeightedScore >= 5.0);
    const isFailed = course.status === "Not passed" || (remainingWeight === 0 && currentWeightedScore < 5.0);

    let statusBadgeClass = "grade-badge--inprogress";
    let statusText = `Đang học (${completedWeight}%)`;

    if (isPassed) {
      statusBadgeClass = "grade-badge--passed";
      statusText = "Passed";
    } else if (isFailed) {
      statusBadgeClass = "grade-badge--failed";
      statusText = "Not passed";
    }

    // Header
    const header = document.createElement("div");
    header.className = "grade-card__header";

    const titleGroup = document.createElement("div");
    titleGroup.className = "grade-card__title-group";

    const codeEl = document.createElement("div");
    codeEl.className = "grade-card__code";
    codeEl.textContent = course.courseCode || "UNKNOWN";
    titleGroup.appendChild(codeEl);

    if (course.courseName && course.courseName !== course.courseCode) {
      let cleanCourseName = course.courseName
        .replace(/\s*\([^)]*,?\s*$/g, "")
        .replace(/[()]/g, " ")
        .replace(/^[-–:,/.\s]+|[-–:,/.\s]+$/g, "")
        .replace(/\s{2,}/g, " ")
        .trim();
      if (!cleanCourseName) cleanCourseName = course.courseName;
      const nameEl = document.createElement("div");
      nameEl.className = "grade-card__name";
      nameEl.textContent = cleanCourseName;
      titleGroup.appendChild(nameEl);
    }

    if (course.term) {
      const termEl = document.createElement("span");
      termEl.className = "grade-card__term";
      termEl.textContent = course.term;
      titleGroup.appendChild(termEl);
    }

    const badgeEl = document.createElement("span");
    badgeEl.className = `grade-badge ${statusBadgeClass}`;
    badgeEl.textContent = statusText;

    header.appendChild(titleGroup);
    header.appendChild(badgeEl);
    card.appendChild(header);

    // Summary row
    const summaryRow = document.createElement("div");
    summaryRow.className = "grade-summary-row";
    summaryRow.innerHTML = `
      <span>Điểm tích luỹ: <strong class="grade-summary-val">${currentWeightedScore.toFixed(2)}</strong> / 10</span>
      <span>Đã hoàn thành: <strong>${completedWeight}%</strong></span>
    `;
    card.appendChild(summaryRow);

    // Progress bar
    const progressWrap = document.createElement("div");
    progressWrap.className = "grade-progress-wrap";
    const progressBar = document.createElement("div");
    progressBar.className = "grade-progress-bar" + (isPassed ? " grade-progress-bar--passed" : "");
    const pct = Math.min(100, Math.max(0, currentWeightedScore * 10));
    progressBar.style.width = `${pct}%`;
    progressWrap.appendChild(progressBar);
    card.appendChild(progressWrap);

    // Predictor Box
    const predictorBox = document.createElement("div");
    predictorBox.className = "grade-predictor-box";

    if (remainingWeight <= 0) {
      const doneText = course.average != null
        ? `Môn học đã hoàn tất. Điểm tổng kết: <strong>${course.average.toFixed(1)}</strong> (${course.status || (isPassed ? "Passed" : "Not passed")})`
        : `Môn học đã hoàn tất toàn bộ 100% trọng số. Điểm tổng: <strong>${currentWeightedScore.toFixed(2)}</strong>`;
      predictorBox.innerHTML = `<div style="font-size:12px; color:var(--text); line-height:1.4;">${doneText}</div>`;
    } else {
      const predHeader = document.createElement("div");
      predHeader.className = "grade-predictor-header";
      predHeader.innerHTML = `
        <span>Dự báo điểm thi (FE / PE):</span>
        <span>Mục tiêu: <strong class="target-display">5.0</strong></span>
      `;
      predictorBox.appendChild(predHeader);

      const sliderRow = document.createElement("div");
      sliderRow.className = "grade-slider-row";

      const slider = document.createElement("input");
      slider.type = "range";
      slider.className = "grade-slider";
      slider.min = "5.0";
      slider.max = "9.0";
      slider.step = "0.1";
      slider.value = "5.0";

      const targetNum = document.createElement("span");
      targetNum.className = "grade-target-num";
      targetNum.textContent = "5.0";

      sliderRow.appendChild(slider);
      sliderRow.appendChild(targetNum);
      predictorBox.appendChild(sliderRow);

      const resultBox = document.createElement("div");
      resultBox.className = "grade-predict-result";
      predictorBox.appendChild(resultBox);

      const updatePrediction = (targetVal) => {
        targetNum.textContent = targetVal.toFixed(1);
        const targetDisplay = predHeader.querySelector(".target-display");
        if (targetDisplay) targetDisplay.textContent = targetVal.toFixed(1);

        if (typeof calculateRequiredExamScore !== "function") return;
        const res = calculateRequiredExamScore(categories, bonus, targetVal, 4.0);

        resultBox.className = "grade-predict-result";
        if (res.status === "pass_guaranteed") {
          resultBox.classList.add("grade-predict-result--guaranteed");
          resultBox.innerHTML = `<strong>Chắc chắn qua môn!</strong> Chỉ cần thi ≥ <strong>4.0</strong> (tránh điểm liệt) là đạt mục tiêu ${targetVal.toFixed(1)}.`;
        } else if (res.status === "achievable") {
          resultBox.classList.add("grade-predict-result--achievable");
          resultBox.innerHTML = `Cần thi tối thiểu: <span class="grade-predict-score">${res.minRequired.toFixed(1)}</span> để đạt tổng kết ${targetVal.toFixed(1)}.`;
        } else if (res.status === "impossible") {
          resultBox.classList.add("grade-predict-result--impossible");
          resultBox.innerHTML = `Không thể đạt ${targetVal.toFixed(1)} (Điểm thi cần > 10.0: ${res.requiredScore.toFixed(1)}).`;
        }
      };

      slider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value) || 5.0;
        updatePrediction(val);
      });

      updatePrediction(5.0);
    }
    card.appendChild(predictorBox);

    // Collapsible breakdown accordion
    if (categories.length > 0 || bonus > 0) {
      const details = document.createElement("details");
      details.className = "grade-details-accordion";

      const summary = document.createElement("summary");
      summary.className = "grade-details-summary";
      summary.innerHTML = `<span>Xem bảng điểm chi tiết (${categories.length} mục)</span>`;
      details.appendChild(summary);

      const table = document.createElement("table");
      table.className = "grade-table";
      const thead = document.createElement("thead");
      thead.innerHTML = `<tr><th>Thành phần</th><th>Trọng số</th><th style="text-align:right;">Điểm</th></tr>`;
      table.appendChild(thead);

      const tbody = document.createElement("tbody");
      categories.forEach((cat) => {
        const tr = document.createElement("tr");
        const valText = cat.value != null ? cat.value : "-";
        tr.innerHTML = `
          <td><strong>${cat.category || ""}</strong>${cat.items && cat.items.length > 1 ? ` (${cat.items.map(i => i.name).join(", ")})` : ""}</td>
          <td>${cat.weight}%</td>
          <td style="text-align:right; font-weight:600;">${valText}</td>
        `;
        tbody.appendChild(tr);
      });

      if (bonus > 0) {
        const trBonus = document.createElement("tr");
        trBonus.innerHTML = `
          <td><strong>Bonus</strong></td>
          <td>-</td>
          <td style="text-align:right; font-weight:600; color:var(--accent);">+${bonus}</td>
        `;
        tbody.appendChild(trBonus);
      }

      table.appendChild(tbody);
      details.appendChild(table);
      card.appendChild(details);
    }

    list.appendChild(card);
  });

  container.appendChild(list);
}

function loadAndRenderStudentGrades() {
  const loc = getChromeStorageLocal();
  if (loc) {
    loc.get(["studentGrades"], (res) => {
      const grades = (res && res.studentGrades) || {};
      renderStudentGrades(grades);
    });
  } else {
    try {
      const saved = JSON.parse(localStorage.getItem("studentGrades") || "{}");
      renderStudentGrades(saved);
    } catch (_) {
      renderStudentGrades({});
    }
  }
}

window.renderStudentGrades = renderStudentGrades;
window.loadAndRenderStudentGrades = loadAndRenderStudentGrades;

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function renderTodayAgendaBanner(schedule, examEvents = []) {
  if (typeof computeTodayAgenda !== "function") return "";
  const agenda = computeTodayAgenda({ classEvents: schedule, examEvents, now: new Date() });
  if (!agenda || agenda.status === AGENDA_STATUS.NO_DATA) return "";

  let badgeHtml = "";
  let titleHtml = "";
  let metaHtml = "";
  let counterHtml = "";
  let clickableClass = "";
  let targetUrl = "";

  if (agenda.status === AGENDA_STATUS.IN_PROGRESS && agenda.currentEvent) {
    const ev = agenda.currentEvent;
    badgeHtml = `<span class="agenda-dot agenda-dot--pulse"></span><span>Đang diễn ra • Còn ${formatMinutesCountdown(agenda.remainingMinutes)}</span>`;
    titleHtml = `${escapeHtml(ev.title || "Buổi học")}`;
    const loc = ev.isOnline ? "Học Online" : (ev.location || "Chưa rõ phòng");
    metaHtml = `
      <div class="agenda-next-row">
        ${ev.slot ? `<span class="agenda-chip-meta">${escapeHtml(ev.slot)}</span>` : ""}
        <span class="agenda-chip-code">${escapeHtml(loc)}</span>
      </div>
    `;
    if (agenda.totalRemainingToday > 0) {
      counterHtml = `Còn ${agenda.totalRemainingToday} ca hôm nay`;
    }
    if (ev.detailUrl) {
      clickableClass = "agenda-card--clickable";
      targetUrl = ev.detailUrl;
    }
  } else if (agenda.status === AGENDA_STATUS.UPCOMING && agenda.nextEvent) {
    const ev = agenda.nextEvent;
    badgeHtml = `<span class="agenda-dot"></span><span>Ca tiếp theo • Sau ${formatMinutesCountdown(agenda.minutesUntilStart)}</span>`;
    titleHtml = `${escapeHtml(ev.title || "Buổi học")}`;
    const loc = ev.isOnline ? "Học Online" : (ev.location || "Chưa rõ phòng");
    metaHtml = `
      <div class="agenda-next-row">
        ${ev.slot ? `<span class="agenda-chip-meta">${escapeHtml(ev.slot)}</span>` : ""}
        <span class="agenda-chip-code">${escapeHtml(loc)}</span>
      </div>
    `;
    counterHtml = `Còn ${agenda.totalRemainingToday} ca hôm nay`;
    if (ev.detailUrl) {
      clickableClass = "agenda-card--clickable";
      targetUrl = ev.detailUrl;
    }
  } else if (agenda.status === AGENDA_STATUS.COMPLETED_TODAY) {
    badgeHtml = `<span class="agenda-dot agenda-dot--done"></span><span>Hoàn thành lịch học</span>`;
    titleHtml = "Đã xong các ca học hôm nay";
    if (agenda.nextEvent) {
      const rd = agenda.nextEvent.rawDate;
      const dateStr = rd ? `${rd.day}/${rd.month}` : "ngày tiếp theo";
      const slotStr = agenda.nextEvent.slot || "";
      const locStr = agenda.nextEvent.isOnline ? "Online" : (agenda.nextEvent.location || "");
      metaHtml = `
        <div class="agenda-next-row">
          <span class="agenda-next-label">Ca tiếp theo:</span>
          <span class="agenda-chip-code">${escapeHtml(agenda.nextEvent.title || "")}</span>
          <span class="agenda-chip-meta">${dateStr}</span>
          ${slotStr ? `<span class="agenda-chip-meta">${escapeHtml(slotStr)}</span>` : ""}
          ${locStr ? `<span class="agenda-chip-meta">${escapeHtml(locStr)}</span>` : ""}
        </div>
      `;
    } else {
      metaHtml = `<span>Bạn không còn ca học nào trong tuần này.</span>`;
    }
  } else if (agenda.status === AGENDA_STATUS.FREE_TODAY) {
    badgeHtml = `<span class="agenda-dot agenda-dot--free"></span><span>Lịch trống hôm nay</span>`;
    titleHtml = "Không có ca học nào hôm nay";
    if (agenda.nextEvent) {
      const rd = agenda.nextEvent.rawDate;
      const dateStr = rd ? `${rd.day}/${rd.month}` : "sắp tới";
      const slotStr = agenda.nextEvent.slot || "";
      const locStr = agenda.nextEvent.isOnline ? "Online" : (agenda.nextEvent.location || "");
      metaHtml = `
        <div class="agenda-next-row">
          <span class="agenda-next-label">Ca học gần nhất:</span>
          <span class="agenda-chip-code">${escapeHtml(agenda.nextEvent.title || "")}</span>
          <span class="agenda-chip-meta">${dateStr}</span>
          ${slotStr ? `<span class="agenda-chip-meta">${escapeHtml(slotStr)}</span>` : ""}
          ${locStr ? `<span class="agenda-chip-meta">${escapeHtml(locStr)}</span>` : ""}
        </div>
      `;
    } else {
      metaHtml = `<span>Tận hưởng ngày nghỉ của bạn nhé!</span>`;
    }
  }

  let examAlertHtml = "";
  if (agenda.todayExams && agenda.todayExams.length > 0) {
    const exam = agenda.todayExams[0];
    examAlertHtml = `
      <div class="agenda-exam-alert">
        <svg class="icon" aria-hidden="true" style="width:14px;height:14px;flex-shrink:0;"><use href="#icon-calendar"/></svg>
        <span>Lịch thi hôm nay: <strong>${escapeHtml(exam.title || "")}</strong> (${escapeHtml(exam.time || "")} • ${escapeHtml(exam.room || "")})</span>
      </div>
    `;
  }

  const isWeek = currentScheduleViewMode === "week";
  const viewToggleHtml = `
    <div class="view-toggle" role="group" aria-label="Chế độ xem lịch">
      <button type="button" id="viewListBtn" class="view-toggle__btn ${!isWeek ? 'active' : ''}" title="Xem dạng danh sách">
        <svg class="icon icon--xs" aria-hidden="true"><use href="#icon-list"/></svg>
        <span class="view-toggle__label">Danh sách</span>
      </button>
      <button type="button" id="viewWeekBtn" class="view-toggle__btn ${isWeek ? 'active' : ''}" title="Xem thời khóa biểu tuần">
        <svg class="icon icon--xs" aria-hidden="true"><use href="#icon-grid"/></svg>
        <span class="view-toggle__label">Lịch tuần</span>
      </button>
    </div>
  `;

  return `
    <div class="agenda-banner">
      <div class="agenda-card agenda-card--${agenda.status.toLowerCase()} ${clickableClass}" ${targetUrl ? `data-url="${escapeHtml(targetUrl)}"` : ""}>
        <div class="agenda-card__header">
          <div class="agenda-badge-group">
            <div class="agenda-badge">${badgeHtml}</div>
            ${counterHtml ? `<span class="agenda-counter">${escapeHtml(counterHtml)}</span>` : ""}
          </div>
          ${viewToggleHtml}
        </div>
        <div class="agenda-card__body">
          <div class="agenda-title">${titleHtml}</div>
          <div class="agenda-meta">${metaHtml}</div>
        </div>
        ${examAlertHtml}
      </div>
    </div>
  `;
}
window.renderTodayAgendaBanner = renderTodayAgendaBanner;

function syncScheduleViewToggleButtons() {
  const viewListBtn = document.getElementById("viewListBtn");
  const viewWeekBtn = document.getElementById("viewWeekBtn");
  if (!viewListBtn || !viewWeekBtn) return;
  if (currentScheduleViewMode === "week") {
    viewListBtn.classList.remove("active");
    viewWeekBtn.classList.add("active");
  } else {
    viewListBtn.classList.add("active");
    viewWeekBtn.classList.remove("active");
  }
}

function renderClassScheduleWeek(container, stored, now = new Date()) {
  const getWeekRange = typeof getWeekDateRange === "function" ? getWeekDateRange : (window.getWeekDateRange || globalThis.getWeekDateRange);
  const groupWeek = typeof groupScheduleByWeekAndSlot === "function" ? groupScheduleByWeekAndSlot : (window.groupScheduleByWeekAndSlot || globalThis.groupScheduleByWeekAndSlot);
  const getTimingStatus = typeof getSlotTimingStatus === "function" ? getSlotTimingStatus : (window.getSlotTimingStatus || globalThis.getSlotTimingStatus);
  if (!getWeekRange || !groupWeek) return;

  const weekRange = getWeekRange(now, currentWeekOffset);
  const grouped = groupWeek(stored, weekRange);

  const weekContainer = document.createElement("div");
  weekContainer.className = "week-matrix-container";

  // Navigation Header
  const nav = document.createElement("div");
  nav.className = "week-matrix-nav";

  const controls = document.createElement("div");
  controls.className = "week-matrix-nav__controls";

  const prevBtn = document.createElement("button");
  prevBtn.type = "button";
  prevBtn.id = "prevWeekBtn";
  prevBtn.className = "week-matrix-nav__btn";
  prevBtn.title = "Tuần trước";
  prevBtn.innerHTML = '<svg class="icon icon--xs" aria-hidden="true"><use href="#icon-chevron-left"/></svg>';
  prevBtn.addEventListener("click", () => {
    currentWeekOffset -= 1;
    renderClassSchedule(stored);
  });

  const nextBtn = document.createElement("button");
  nextBtn.type = "button";
  nextBtn.id = "nextWeekBtn";
  nextBtn.className = "week-matrix-nav__btn";
  nextBtn.title = "Tuần sau";
  nextBtn.innerHTML = '<svg class="icon icon--xs" aria-hidden="true"><use href="#icon-chevron-right"/></svg>';
  nextBtn.addEventListener("click", () => {
    currentWeekOffset += 1;
    renderClassSchedule(stored);
  });

  controls.appendChild(prevBtn);
  controls.appendChild(nextBtn);

  const title = document.createElement("div");
  title.className = "week-matrix-nav__title";
  const two = (n) => String(n).padStart(2, "0");
  const dStart = weekRange.startMonday;
  const dEnd = weekRange.endSunday;
  title.textContent = `${two(dStart.getDate())}/${two(dStart.getMonth() + 1)} – ${two(dEnd.getDate())}/${two(dEnd.getMonth() + 1)}/${dEnd.getFullYear()}`;

  const todayBtn = document.createElement("button");
  todayBtn.type = "button";
  todayBtn.id = "todayWeekBtn";
  todayBtn.className = "week-matrix-nav__today-btn";
  todayBtn.textContent = "Hôm nay";
  todayBtn.addEventListener("click", () => {
    currentWeekOffset = 0;
    renderClassSchedule(stored);
  });

  nav.appendChild(controls);
  nav.appendChild(title);
  nav.appendChild(todayBtn);
  weekContainer.appendChild(nav);

  // Matrix Grid
  const matrix = document.createElement("div");
  matrix.className = "week-matrix";

  // Corner cell
  const corner = document.createElement("div");
  corner.className = "week-matrix__head-cell";
  corner.innerHTML = '<span class="week-matrix__day-name">Slot</span>';
  matrix.appendChild(corner);

  // Header row (7 days)
  const DAY_LABELS = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"];
  weekRange.days.forEach((d, idx) => {
    const headCell = document.createElement("div");
    headCell.className = "week-matrix__head-cell";
    if (d.isToday) headCell.classList.add("is-today");

    const nameSpan = document.createElement("span");
    nameSpan.className = "week-matrix__day-name";
    nameSpan.textContent = DAY_LABELS[idx];

    const numSpan = document.createElement("span");
    numSpan.className = "week-matrix__day-num";
    numSpan.textContent = two(d.day);

    headCell.appendChild(nameSpan);
    headCell.appendChild(numSpan);
    matrix.appendChild(headCell);
  });

  // 6 Slot rows
  const SLOTS = [
    { slot: 1, time: "07:30" },
    { slot: 2, time: "10:00" },
    { slot: 3, time: "12:50" },
    { slot: 4, time: "15:20" },
    { slot: 5, time: "17:50" },
    { slot: 6, time: "20:20" },
  ];

  SLOTS.forEach((st) => {
    const slotLabelCell = document.createElement("div");
    slotLabelCell.className = "week-matrix__slot-cell";

    const sName = document.createElement("span");
    sName.className = "week-matrix__slot-name";
    sName.textContent = `Slot ${st.slot}`;

    const sTime = document.createElement("span");
    sTime.className = "week-matrix__slot-time";
    sTime.textContent = st.time;

    slotLabelCell.appendChild(sName);
    slotLabelCell.appendChild(sTime);
    matrix.appendChild(slotLabelCell);

    weekRange.days.forEach((d) => {
      const cell = document.createElement("div");
      cell.className = "week-matrix__cell";
      if (d.isToday) cell.classList.add("is-today");

      const key = `${d.isoDay}_${st.slot}`;
      const events = grouped[key] || [];

      // Check slot status for this cell
      const cellStatus = typeof getTimingStatus === "function"
        ? getTimingStatus(null, d, st.slot, now)
        : "upcoming";

      if (cellStatus === "past") {
        cell.classList.add("is-past");
      } else if (cellStatus === "in_progress") {
        cell.classList.add("is-in-progress");
      }

      if (events.length > 0) {
        cell.classList.add("week-cell--has-class");
        events.forEach((ev) => {
          const card = document.createElement("div");
          card.className = "week-matrix__card";
          card.tabIndex = 0;
          card.setAttribute("role", "button");
          card.setAttribute("aria-label", `${ev.title || "Môn học"} Slot ${st.slot}`);

          const evStatus = typeof getTimingStatus === "function"
            ? getTimingStatus(ev, d, st.slot, now)
            : cellStatus;

          if (evStatus === "in_progress") {
            card.classList.add("is-in-progress");
          } else if (evStatus === "past") {
            card.classList.add("is-past");
          }

          const header = document.createElement("div");
          header.className = "week-matrix__card-header";

          const code = document.createElement("span");
          code.className = "week-matrix__card-code";
          code.textContent = ev.title || "Môn học";

          header.appendChild(code);

          if (evStatus === "in_progress") {
            const liveDot = document.createElement("span");
            liveDot.className = "week-matrix__live-dot";
            liveDot.title = "Đang trong giờ học";
            header.appendChild(liveDot);
          } else {
            const dot = document.createElement("span");
            const rawStatus = (ev.attendanceStatus || "not yet").toLowerCase();
            let dotClass = "notyet";
            if (rawStatus.includes("absent")) dotClass = "absent";
            else if (rawStatus.includes("attended")) dotClass = "attended";
            dot.className = `week-matrix__dot ${dotClass}`;
            header.appendChild(dot);
          }

          card.appendChild(header);

          const loc = document.createElement("span");
          loc.className = "week-matrix__card-loc";
          if (ev.isOnline) {
            loc.className += " online";
            loc.textContent = "Online";
          } else if (ev.location) {
            loc.textContent = (ev.location || "").replace(/\s*-\s*$/, "").trim();
          }
          card.appendChild(loc);

          const footer = document.createElement("div");
          footer.className = "week-matrix__card-footer";

          if (evStatus === "in_progress") {
            const liveBadge = document.createElement("span");
            liveBadge.className = "week-matrix__badge-live";
            liveBadge.textContent = "Đang học";
            footer.appendChild(liveBadge);
          }

          if (ev.rawDate && typeof ev.rawDate.startHour === "number") {
            const time = document.createElement("span");
            time.className = "week-matrix__card-time";
            time.textContent = `${two(ev.rawDate.startHour)}:${two(ev.rawDate.startMinute)}`;
            footer.appendChild(time);
          }

          if (footer.childNodes.length > 0) {
            card.appendChild(footer);
          }

          if (ev.detailUrl) {
            const openDetail = () => {
              const url = ev.detailUrl;
              try { chrome.tabs.create({ url }); } catch (_) { window.open(url, "_blank"); }
            };
            card.addEventListener("click", openDetail);
            card.addEventListener("keydown", (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                openDetail();
              }
            });
          }

          cell.appendChild(card);
        });
      }

      matrix.appendChild(cell);
    });
  });

  weekContainer.appendChild(matrix);
  container.appendChild(weekContainer);
}

function renderClassSchedule(schedule) {
  const container = document.getElementById("scheduleTab");
  if (!container) return;

  // Clear existing
  while (container.firstChild) container.removeChild(container.firstChild);

  // The range filter only narrows what is shown; nothing is removed from storage.
  const stored = Array.isArray(schedule) ? schedule : [];
  if (stored.length > 0) {
    lastRenderedClassSchedule = stored;
  }
  const mode = getClassRangeFilter();
  const visible = filterClassScheduleByRange(stored, mode);
  syncClassFilterButton();
  syncScheduleViewToggleButtons();

  // Absence rate and detailed attendance stats per course
  const showAttendanceStats = getShowAttendanceStats();
  const attendanceStatsByCourse = typeof computeCourseAttendanceStats === "function" ? computeCourseAttendanceStats(stored) : {};
  const attendanceByCourse = computeAttendanceByCourse(stored);

  // Update tab label with count
  const btn = document.getElementById("scheduleTabBtn");
  const tabText = btn?.querySelector(".tab-btn__text");
  if (tabText) {
    tabText.textContent = visible.length ? `Lịch học (${visible.length})` : "Lịch học";
  }

  // Render Today's Agenda banner at top of schedule tab
  let examEvents = [];
  try {
    const rawExams = localStorage.getItem("examSchedule");
    if (rawExams) examEvents = JSON.parse(rawExams);
  } catch (_) {}

  const bannerHtml = renderTodayAgendaBanner(stored, examEvents);
  if (bannerHtml) {
    const bannerWrapper = document.createElement("div");
    bannerWrapper.innerHTML = bannerHtml.trim();
    const bannerEl = bannerWrapper.firstElementChild;
    if (bannerEl) {
      const card = bannerEl.querySelector(".agenda-card--clickable");
      if (card && card.dataset.url) {
        const url = card.dataset.url;
        const openUrl = (e) => {
          if (e && e.target && e.target.closest(".view-toggle")) return;
          try { chrome.tabs.create({ url }); } catch (_) { window.open(url, '_blank'); }
        };
        card.tabIndex = 0;
        card.setAttribute("role", "button");
        card.setAttribute("aria-label", `Xem chi tiết buổi học`);
        card.addEventListener("click", openUrl);
        card.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            if (e.target && e.target.closest(".view-toggle")) return;
            e.preventDefault();
            openUrl(e);
          }
        });
      }
      container.appendChild(bannerEl);
    }
  }

  if (stored.length === 0) {
    const empty = document.createElement("div");
    empty.className = "schedule-empty";
    empty.textContent = "Chưa có lịch học. Nhấn «Đồng bộ lịch học» để tải.";
    container.appendChild(empty);
    return;
  }

  if (currentScheduleViewMode === "week") {
    renderClassScheduleWeek(container, stored);
    return;
  }

  // Normalize and sort schedule by date/time ascending
  const toMillis = (ev) => {
    if (ev && ev.rawDate) {
      const rd = ev.rawDate;
      // month in JS Date is 0-based
      return new Date(rd.year, (rd.month || 1) - 1, rd.day || 1, rd.startHour || 0, rd.startMinute || 0, 0).getTime();
    }
    if (ev && ev.start) {
      try { return new Date(ev.start).getTime(); } catch (_) {}
    }
    return Number.MAX_SAFE_INTEGER; // push unknown dates to the end
  };
  const sorted = [...visible].sort((a, b) => toMillis(a) - toMillis(b));

  if (visible.length === 0) {
    const empty = document.createElement("div");
    empty.className = "schedule-empty";
    empty.textContent = "Không có tiết học nào trong khoảng đã lọc. Đổi bộ lọc để xem thêm.";
    container.appendChild(empty);
    return;
  }

  const grid = document.createElement("div");
  grid.className = "schedule-grid";

  // Helper formatters using rawDate if present
  const two = n => String(n).padStart(2, '0');
  const fmtDate = rd => `${two(rd.day)}/${two(rd.month)}/${rd.year}`;
  const fmtTime = (h,m) => `${two(h)}:${two(m)}`;

  sorted.forEach(ev => {
    const card = document.createElement("div");
    card.className = "class-card";

    const head = document.createElement("div");
    head.className = "class-card__head";

    const code = document.createElement("span");
    code.className = "class-code";
    code.textContent = ev.title || "Môn học";

    // Badges on the right of the header:
    // Slot -> Location (Online if online, Room if offline) -> Risk (if any) -> Attendance status
    const headBadges = document.createElement("div");
    headBadges.className = "class-card__badges";

    // 1. Slot/Type chip
    const chipType = document.createElement("span");
    chipType.className = "chip type";
    const dotType = document.createElement("span"); dotType.className = "dot";
    chipType.appendChild(dotType);
    chipType.appendChild(document.createTextNode((ev.slot || ev.type || "Slot ?").toString()));
    headBadges.appendChild(chipType);

    // 2. Format / Location chip: Online classes hide room, offline classes show room
    if (ev.isOnline) {
      const chipOnline = document.createElement("span");
      chipOnline.className = "chip online";
      const dotOnline = document.createElement("span"); dotOnline.className = "dot";
      chipOnline.appendChild(dotOnline);
      chipOnline.appendChild(document.createTextNode("Online"));
      headBadges.appendChild(chipOnline);
    } else if (ev.location) {
      const chipRoom = document.createElement("span");
      chipRoom.className = "chip room";
      const dot = document.createElement("span"); dot.className = "dot";
      chipRoom.appendChild(dot);
      const roomText = (ev.location || "").replace(/\s*-\s*$/, "").trim();
      chipRoom.appendChild(document.createTextNode(roomText));
      headBadges.appendChild(chipRoom);
    }

    // 3. Attendance-risk chip — shown on every card of a course whose graded sessions so far
    // put it at or past the early-warning line, using the same rate for all of that course's
    // cards regardless of which specific session this one is.
    if (showAttendanceStats) {
      const courseAttendance = attendanceByCourse[ev.title];
      const riskLevel = courseAttendance ? attendanceRiskLevel(courseAttendance.rate) : null;
      if (riskLevel) {
        const chipRisk = document.createElement("span");
        chipRisk.className = `chip risk-${riskLevel}`;
        const dotRisk = document.createElement("span"); dotRisk.className = "dot";
        chipRisk.appendChild(dotRisk);
        const pct = Math.round(courseAttendance.rate * 100);
        chipRisk.appendChild(document.createTextNode(`${pct}% vắng`));
        headBadges.appendChild(chipRisk);
      }
    }

    // 4. Attendance status chip
    const attendanceChip = document.createElement("span");
    attendanceChip.className = "chip attendance";
    const dotAtt = document.createElement("span");
    dotAtt.className = "dot";
    attendanceChip.appendChild(dotAtt);
    const rawStatus = (ev.attendanceStatus || "not yet").toLowerCase();
    let statusClass = "notyet";
    let statusLabel = "Not yet";
    if (rawStatus.includes("absent")) { statusClass = "absent"; statusLabel = "Absent"; }
    else if (rawStatus.includes("attended")) { statusClass = "attended"; statusLabel = "Attended"; }
    attendanceChip.classList.add(statusClass);
    attendanceChip.appendChild(document.createTextNode(statusLabel));
    headBadges.appendChild(attendanceChip);

    head.appendChild(code);
    head.appendChild(headBadges);

    // The whole card opens the detail page — see the click/keydown wiring appended to
    // `card` below, right after this event object's chips are all built.
    if (ev.detailUrl) {
      const openDetail = async () => {
        const url = ev.detailUrl;

        // 1) Fetch the detail page directly and parse attendance
        try {
          const res = await fetch(url, { credentials: 'include' });
          const html = await res.text();
          const parseAttendance = (html) => {
            try {
              const doc = new DOMParser().parseFromString(html, 'text/html');
              // Pattern 1: table row <td>Attendance:</td><td>STATUS</td>
              const tds = Array.from(doc.querySelectorAll('td'));
              for (let i = 0; i < tds.length; i++) {
                const label = (tds[i].textContent || '').trim().toLowerCase().replace(/[:\s]+$/, '');
                if (label === 'attendance' && tds[i+1]) {
                  const status = (tds[i+1].textContent || '').trim().toLowerCase();
                  if (status) return { status };
                }
              }
              // Pattern 2: <font color="...">status</font>
              const font = doc.querySelector('font[color]');
              if (font) {
                return {
                  status: (font.textContent || '').trim().toLowerCase(),
                  color: (font.getAttribute('color') || '').toLowerCase()
                };
              }
              // Pattern 3: fallback scan
              const txt = (doc.body?.innerText || '').toLowerCase();
              if (txt.includes('absent')) return { status: 'absent' };
              if (txt.includes('attended')) return { status: 'attended' };
              if (txt.includes('not yet')) return { status: 'not yet' };
              return null;
            } catch { return null; }
          };
          const found = parseAttendance(html);

          if (found && found.status) {
            // 2) Update local schedule immediately
            const keyOf = (obj) => obj && obj.rawDate ? `${(obj.title||'').trim()}__${obj.rawDate.year}-${obj.rawDate.month}-${obj.rawDate.day}__${obj.rawDate.startHour}:${obj.rawDate.startMinute}` : null;
            let saved = JSON.parse(localStorage.getItem('classSchedule') || '[]');
            const k = keyOf(ev);
            let changed = false;
            saved = saved.map(it => {
              if (keyOf(it) === k) {
                if (it.attendanceStatus !== found.status) changed = true;
                it.attendanceStatus = found.status;
                if (found.color) it.attendanceColor = found.color;
              }
              return it;
            });
            if (changed) {
              persistClassSchedule(JSON.stringify(saved));
              try { window.renderClassSchedule && window.renderClassSchedule(saved); } catch (_) {}
              // silent update – no toast
            }
          }
        } catch (err) {
          console.warn('Fetch detail failed:', err);
        }

        // 3) Open the detail page for the user
        try { chrome.tabs.create({ url }); } catch (_) { window.open(url, '_blank'); }
      };

      card.classList.add("class-card--clickable");
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", `Xem chi tiết ${ev.title || "buổi học"}`);
      card.addEventListener("click", openDetail);
      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openDetail();
        }
      });
    }

    card.appendChild(head);

    const meta = document.createElement("div");
    meta.className = "class-meta";

    const addMeta = (label, value, valueClass = "") => {
      const row = document.createElement("div");
      row.className = "meta-row";
      const lab = document.createElement("span");
      lab.className = "meta-label";
      lab.textContent = `${label}:`;
      const val = document.createElement("span");
      val.className = "meta-value" + (valueClass ? ` ${valueClass}` : "");
      val.textContent = value || "—";
      row.appendChild(lab);
      row.appendChild(val);
      meta.appendChild(row);
    };

    if (ev.rawDate) {
      addMeta("Ngày", fmtDate(ev.rawDate));
      addMeta("Giờ", `${fmtTime(ev.rawDate.startHour, ev.rawDate.startMinute)} – ${fmtTime(ev.rawDate.endHour, ev.rawDate.endMinute)}`);
    }

    if (showAttendanceStats) {
      const courseStats = attendanceStatsByCourse[ev.title];
      if (courseStats && courseStats.totalGraded > 0) {
        const pct = Math.round(courseStats.rate * 1000) / 10;
        let attText = `${courseStats.attended} có mặt • ${courseStats.absent} vắng (${pct}%)`;
        let statusClass = "attendance-safe";
        if (courseStats.rate >= 0.2 || (courseStats.hasFullSchedule && courseStats.remainingAbsent <= 0)) {
          statusClass = "attendance-danger";
        } else if (courseStats.rate >= 0.15) {
          statusClass = "attendance-warning";
        }

        if (courseStats.hasFullSchedule) {
          if (courseStats.remainingAbsent > 0) {
            attText += ` • Còn được nghỉ ${courseStats.remainingAbsent} buổi`;
          } else if (courseStats.remainingAbsent === 0) {
            attText += ` • Đã chạm trần 20%, không được nghỉ thêm`;
          } else {
            attText += ` • Nguy cơ cấm thi (quá 20%)`;
          }
        }

        addMeta("Điểm danh", attText, statusClass);
      }
    }

    card.appendChild(meta);

    grid.appendChild(card);
  });

  container.appendChild(grid);
}
window.renderClassSchedule = renderClassSchedule;
window.renderClassScheduleWeek = renderClassScheduleWeek;

  // Sau khi renderClassSchedule đã gắn window; tránh race với callback storage
  const stMerge = getChromeStorageLocal();
  if (stMerge) {
    try {
      stMerge.get(["classSchedule"], (r) => {
        if (chrome.runtime.lastError || !r.classSchedule) return;
        if (r.classSchedule === localStorage.getItem("classSchedule")) return;
        try {
          persistClassSchedule(r.classSchedule);
          const parsed = JSON.parse(r.classSchedule);
          renderClassSchedule(parsed);
        } catch (e) {
          console.error("Merge class schedule from storage failed:", e);
        }
      });
    } catch (_) { /* no storage API */ }
  }

  // Documentation link event
  if (docsLink) {
    docsLink.addEventListener("click", (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: "https://yunkhngn.github.io/fptu-schedule/" });
    });
  }

  // Privacy policy link event
  if (privacyLink) {
    privacyLink.addEventListener("click", (e) => {
      e.preventDefault();
      const url = "https://yunkhngn.github.io/fptu-schedule/privacy.html";
      try {
        chrome.tabs.create({ url });
      } catch (_) {
        window.open(url, "_blank");
      }
    });
  }

  // Author profile link event
  if (authorLink) {
    authorLink.addEventListener("click", (e) => {
      e.preventDefault();
      const url = authorLink.getAttribute("href") || "https://www.facebook.com/yun.khngn/";
      try {
        chrome.tabs.create({ url });
      } catch (_) {
        window.open(url, "_blank");
      }
    });
  }

  // View toggle buttons (List vs Week) - delegated event listener on document
  document.addEventListener("click", (e) => {
    const listBtn = e.target.closest("#viewListBtn");
    if (listBtn) {
      e.stopPropagation();
      e.preventDefault();
      currentScheduleViewMode = "list";
      try { localStorage.setItem("fptu_schedule_view_mode", "list"); } catch (_) {}
      syncScheduleViewToggleButtons();
      let saved = [];
      try { saved = JSON.parse(localStorage.getItem("classSchedule") || "[]"); } catch (_) {}
      if ((!saved || saved.length === 0) && lastRenderedClassSchedule.length > 0) {
        saved = lastRenderedClassSchedule;
      }
      renderClassSchedule(saved);
      return;
    }
    const weekBtn = e.target.closest("#viewWeekBtn");
    if (weekBtn) {
      e.stopPropagation();
      e.preventDefault();
      currentScheduleViewMode = "week";
      try { localStorage.setItem("fptu_schedule_view_mode", "week"); } catch (_) {}
      syncScheduleViewToggleButtons();
      let saved = [];
      try { saved = JSON.parse(localStorage.getItem("classSchedule") || "[]"); } catch (_) {}
      if ((!saved || saved.length === 0) && lastRenderedClassSchedule.length > 0) {
        saved = lastRenderedClassSchedule;
      }
      renderClassSchedule(saved);
      return;
    }
  });

  // Get new button elements
  const syncScheduleBtn = document.getElementById("syncScheduleBtn");
  const downloadBtn = document.getElementById("downloadBtn");
  const clearBtn = document.getElementById("clearBtn");

  // Add event handlers for new buttons
  if (syncScheduleBtn) {
    syncScheduleBtn.addEventListener("click", handleSyncClassSchedule);
  }

  if (downloadBtn) {
    downloadBtn.addEventListener("click", () => {
      openQrSyncModal("schedule");
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener("click", handleClearClassSchedule);
  }

  // Grade action buttons
  const syncGradeBtn = document.getElementById("syncGradeBtn");
  const syncAllGradesBtn = document.getElementById("syncAllGradesBtn");
  const clearGradesBtn = document.getElementById("clearGradesBtn");

  function runWithInjectedGradeScript(tabId, actionFn) {
    if (typeof chrome === "undefined" || !chrome.scripting || !chrome.scripting.executeScript) {
      actionFn();
      return;
    }
    chrome.scripting.executeScript(
      {
        target: { tabId },
        files: ["lib/grades.js", "content.js"]
      },
      () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          // tab might already have content scripts or restricted host
        }
        actionFn();
      }
    );
  }

  function saveAndRenderSingleGrade(grade) {
    const loc = getChromeStorageLocal();
    if (loc) {
      loc.get(["studentGrades"], (r) => {
        const grades = (r && r.studentGrades) || {};
        grades[grade.courseCode] = grade;
        loc.set({ studentGrades: grades }, () => {
          showToast(`Đã đồng bộ điểm môn ${grade.courseCode}!`);
          loadAndRenderStudentGrades();
        });
      });
    } else {
      showToast(`Đã đồng bộ điểm môn ${grade.courseCode}!`);
      renderStudentGrades({ [grade.courseCode]: grade });
    }
  }

  async function fetchGradeInTab(tabId, url) {
    // 1. Try sendMessage to content script in tab
    const fromMsg = await new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        { action: "fetchCourseGrade", type: "FETCH_COURSE_GRADE", url },
        (resp) => {
          if (chrome.runtime.lastError || !resp || !resp.ok || !resp.grade) {
            resolve(null);
          } else {
            resolve(resp.grade);
          }
        }
      );
    });
    if (fromMsg) return fromMsg;

    // 2. Direct executeScript fallback inside tab context (with auth cookies)
    if (chrome.scripting && chrome.scripting.executeScript) {
      const fromScript = await new Promise((resolve) => {
        chrome.scripting.executeScript(
          {
            target: { tabId },
            func: async (fetchUrl) => {
              try {
                if (typeof window !== "undefined" && typeof window.fetchCourseGradeFromPage === "function") {
                  return await window.fetchCourseGradeFromPage(fetchUrl);
                }
                const res = await fetch(fetchUrl, { credentials: "include" });
                if (!res.ok) return null;
                const html = await res.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, "text/html");

                const findFn = typeof window !== "undefined" && typeof window.findFapGradeTable === "function"
                  ? window.findFapGradeTable
                  : (typeof findFapGradeTable === "function" ? findFapGradeTable : null);
                const parseFn = typeof window !== "undefined" && typeof window.parseFapGradeTable === "function"
                  ? window.parseFapGradeTable
                  : (typeof parseFapGradeTable === "function" ? parseFapGradeTable : null);

                let table = findFn ? findFn(doc) : null;
                if (!table) table = doc.querySelector('table[summary="Report"]');
                if (!table) {
                  const tables = Array.from(doc.querySelectorAll("table"));
                  for (const tbl of tables) {
                    const text = tbl.textContent || "";
                    if (
                      /Weight/i.test(text) &&
                      /Value/i.test(text) &&
                      (/Grade/i.test(text) || /Course total/i.test(text) || /Average/i.test(text) || /Passed|Not passed/i.test(text))
                    ) {
                      table = tbl;
                      break;
                    }
                  }
                }
                if (table) {
                  if (parseFn) return parseFn(table);
                  const rows = Array.from(table.querySelectorAll("tbody tr"));
                  const categories = [];
                  rows.forEach((r) => {
                    const cells = Array.from(r.cells).map((c) => c.textContent.trim());
                    if (cells.length >= 4) {
                      const weight = parseFloat(cells[2].replace(/%/g, "")) || 0;
                      const val = parseFloat(cells[3]);
                      categories.push({
                        category: cells[0],
                        item: cells[1],
                        weight,
                        value: isNaN(val) ? null : val
                      });
                    }
                  });
                  return { categories, bonus: 0, average: null, status: null };
                }
              } catch (_) {}
              return null;
            },
            args: [url]
          },
          (results) => resolve(results && results[0] && results[0].result)
        );
      });
      if (fromScript) return fromScript;
    }

    return null;
  }

  if (syncGradeBtn) {
    syncGradeBtn.addEventListener("click", () => {
      if (typeof chrome === "undefined" || !chrome.tabs) return;
      findStudentGradeTab(async (err, activeTab) => {
        if (err || !activeTab || !activeTab.id) {
          const open = await showConfirm(
            "Cần tab Bảng điểm FAP để đồng bộ điểm môn hiện tại. Mở Bảng điểm?",
            { title: "Mở FAP", okLabel: "Mở Bảng điểm" }
          );
          if (open) {
            chrome.tabs.create({ url: "https://fap.fpt.edu.vn/Report/Grade", active: true });
          }
          return;
        }

        runWithInjectedGradeScript(activeTab.id, () => {
          chrome.tabs.sendMessage(activeTab.id, { action: "extractStudentGrade", type: "EXTRACT_GRADE_REPORT" }, (resp) => {
            if (chrome.runtime.lastError || !resp || !resp.ok || !resp.grade) {
              // Direct fallback execution via executeScript
              if (chrome.scripting && chrome.scripting.executeScript) {
                chrome.scripting.executeScript(
                  {
                    target: { tabId: activeTab.id },
                    func: () => {
                      try {
                        if (typeof window !== "undefined" && typeof window.extractStudentGradeFromPage === "function") {
                          return window.extractStudentGradeFromPage(document);
                        }
                        if (typeof extractStudentGradeFromPage === "function") {
                          return extractStudentGradeFromPage(document);
                        }
                      } catch (_) {}
                      return null;
                    }
                  },
                  (results) => {
                    const grade = results && results[0] && results[0].result;
                    if (grade && grade.courseCode && grade.courseCode !== "UNKNOWN") {
                      saveAndRenderSingleGrade(grade);
                    } else {
                      showError("Không tìm thấy bảng điểm trên trang hiện tại. Hãy chọn môn trên FAP.");
                    }
                  }
                );
              } else {
                showError("Không tìm thấy bảng điểm trên trang hiện tại. Hãy chọn môn trên FAP.");
              }
              return;
            }

            saveAndRenderSingleGrade(resp.grade);
          });
        });
      });
    });
  }

  if (syncAllGradesBtn) {
    syncAllGradesBtn.addEventListener("click", () => {
      if (typeof chrome === "undefined" || !chrome.tabs) return;
      findStudentGradeTab(async (err, activeTab) => {
        if (err || !activeTab || !activeTab.id) {
          const open = await showConfirm(
            "Cần tab Bảng điểm FAP để quét điểm. Mở Bảng điểm?",
            { title: "Mở FAP", okLabel: "Mở Bảng điểm" }
          );
          if (open) {
            chrome.tabs.create({ url: "https://fap.fpt.edu.vn/Report/Grade", active: true });
          }
          return;
        }

        runWithInjectedGradeScript(activeTab.id, () => {
          chrome.tabs.sendMessage(activeTab.id, { action: "getGradePageControls", type: "GET_GRADE_PAGE_CONTROLS" }, async (resp) => {
            let courses = resp && resp.courses;
            let term = resp && resp.term;

            if (!courses || courses.length === 0) {
              // Direct fallback via executeScript
              if (chrome.scripting && chrome.scripting.executeScript) {
                const fallback = await new Promise((resolve) => {
                  chrome.scripting.executeScript(
                    {
                      target: { tabId: activeTab.id },
                      func: () => {
                        try {
                          if (typeof window !== "undefined" && typeof window.getGradePageControls === "function") {
                            return window.getGradePageControls(document);
                          }
                          if (typeof getGradePageControls === "function") {
                            return getGradePageControls(document);
                          }
                        } catch (_) {}
                        return null;
                      }
                    },
                    (res) => resolve(res && res[0] && res[0].result)
                  );
                });
                courses = fallback && fallback.courses;
                term = fallback && fallback.term;
              }
            }

            if (!courses || courses.length === 0) {
              showError("Không lấy được danh sách môn học từ FAP.");
              return;
            }

            showToast(`Bắt đầu quét ${courses.length} môn học...`, 1500);

            const loc = getChromeStorageLocal();
            let grades = {};
            if (loc) {
              try {
                const r = await new Promise((res) => loc.get(["studentGrades"], res));
                grades = (r && r.studentGrades) || {};
              } catch (_) {}
            }

            let savedCount = 0;
            for (let i = 0; i < courses.length; i++) {
              const c = courses[i];
              showToast(`Đang quét [${i + 1}/${courses.length}]: ${c.courseCode}...`, 1200);

              // If course is active on current page, extract from page directly!
              if (c.isActive && chrome.scripting && chrome.scripting.executeScript) {
                try {
                  const currentGrade = await new Promise((resolve) => {
                    chrome.scripting.executeScript(
                      {
                        target: { tabId: activeTab.id },
                        func: () => {
                          try {
                            if (typeof window !== "undefined" && typeof window.extractStudentGradeFromPage === "function") {
                              return window.extractStudentGradeFromPage(document);
                            }
                            if (typeof extractStudentGradeFromPage === "function") {
                              return extractStudentGradeFromPage(document);
                            }
                          } catch (_) {}
                          return null;
                        }
                      },
                      (res) => resolve(res && res[0] && res[0].result)
                    );
                  });
                  if (currentGrade && currentGrade.categories) {
                    grades[c.courseCode] = {
                      ...currentGrade,
                      courseCode: c.courseCode,
                      courseName: c.courseName || currentGrade.courseName,
                      term: term || currentGrade.term || ""
                    };
                    savedCount++;
                    continue;
                  }
                } catch (_) {}
              }

              // Otherwise fetch URL via the active tab (same-origin with auth cookies)
              try {
                let fetchUrl = c.href;
                if (!fetchUrl || !/^https?:\/\//i.test(fetchUrl)) {
                  try {
                    const base = new URL(activeTab.url || "https://fap.fpt.edu.vn/Report/Grade");
                    if (base.pathname.includes("/Report/Grade")) {
                      base.searchParams.set("courseId", c.id);
                    } else {
                      base.searchParams.set("course", c.id);
                    }
                    fetchUrl = base.href;
                  } catch (_) {
                    fetchUrl = `https://fap.fpt.edu.vn/Report/Grade?courseId=${c.id}`;
                  }
                }
                const parsed = await fetchGradeInTab(activeTab.id, fetchUrl);
                if (!parsed || !parsed.categories) {
                  console.warn("Không lấy được điểm môn:", c.courseCode, fetchUrl);
                  continue;
                }

                grades[c.courseCode] = {
                  courseCode: c.courseCode,
                  courseName: c.courseName || c.courseCode,
                  term: term || "",
                  ...parsed,
                  lastUpdated: Date.now()
                };
                savedCount++;
              } catch (err) {
                console.warn("Lỗi khi tải điểm môn:", c.courseCode, err);
              }
            }

            if (loc) {
              loc.set({ studentGrades: grades }, () => {
                showToast(`Đã quét xong ${savedCount}/${courses.length} môn!`, 3000);
                loadAndRenderStudentGrades();
              });
            } else {
              showToast(`Đã quét xong ${savedCount}/${courses.length} môn!`, 3000);
              renderStudentGrades(grades);
            }
          });
        });
      });
    });
  }

  if (clearGradesBtn) {
    clearGradesBtn.addEventListener("click", async () => {
      const ok = await showConfirm("Bạn có chắc chắn muốn xoá toàn bộ dữ liệu bảng điểm đã lưu?", {
        title: "Xoá bảng điểm",
        okLabel: "Xoá tất cả",
        danger: true
      });
      if (!ok) return;
      const loc = getChromeStorageLocal();
      if (loc) {
        loc.remove(["studentGrades"], () => {
          try { localStorage.removeItem("studentGrades"); } catch (_) {}
          showToast("Đã xoá dữ liệu bảng điểm.");
          loadAndRenderStudentGrades();
        });
      }
    });
  }

  const scheduleFilterBtn = document.getElementById("scheduleFilterBtn");
  const scheduleFilterModal = document.getElementById("scheduleFilterModal");
  const closeScheduleFilter = document.getElementById("closeScheduleFilter");
  const rangeInputs = () => document.querySelectorAll('input[name="classRange"]');

  const closeScheduleFilterModal = () => {
    if (scheduleFilterModal) scheduleFilterModal.style.display = "none";
  };

  if (scheduleFilterBtn && scheduleFilterModal) {
    scheduleFilterBtn.addEventListener("click", () => {
      const current = getClassRangeFilter();
      rangeInputs().forEach((input) => {
        input.checked = input.value === current;
      });
      const showStatsCheckbox = document.getElementById("showAttendanceStats");
      if (showStatsCheckbox) {
        showStatsCheckbox.checked = getShowAttendanceStats();
      }
      scheduleFilterModal.style.display = "block";
    });

    scheduleFilterModal.addEventListener("click", (e) => {
      if (e.target === scheduleFilterModal) closeScheduleFilterModal();
    });
  }

  const resetClassFilter = document.getElementById("resetClassFilter");
  if (resetClassFilter) {
    // Same role as «Chọn tất cả» on the exam filter: back to showing everything.
    resetClassFilter.addEventListener("click", () => {
      rangeInputs().forEach((input) => {
        input.checked = input.value === "all";
      });
      const showStatsCheckbox = document.getElementById("showAttendanceStats");
      if (showStatsCheckbox) {
        showStatsCheckbox.checked = true;
      }
    });
  }

  const applyClassFilter = document.getElementById("applyClassFilter");
  if (applyClassFilter) {
    applyClassFilter.addEventListener("click", () => {
      const picked = [...rangeInputs()].find((input) => input.checked);
      setClassRangeFilter(picked ? picked.value : "all");
      const showStatsCheckbox = document.getElementById("showAttendanceStats");
      if (showStatsCheckbox) {
        setShowAttendanceStats(showStatsCheckbox.checked);
      }
      closeScheduleFilterModal();
      let saved = [];
      try {
        saved = JSON.parse(localStorage.getItem("classSchedule") || "[]");
      } catch (_) {}
      renderClassSchedule(saved);
    });
  }

  if (closeScheduleFilter) {
    closeScheduleFilter.addEventListener("click", closeScheduleFilterModal);
  }

  syncClassFilterButton();

  const loadWeekOptionsBtn = document.getElementById("loadWeekOptionsBtn");
  const syncWeekRangeBtn = document.getElementById("syncWeekRangeBtn");
  if (loadWeekOptionsBtn) {
    loadWeekOptionsBtn.addEventListener("click", handleLoadWeekScheduleOptions);
  }
  if (syncWeekRangeBtn) {
    syncWeekRangeBtn.addEventListener("click", handleSyncClassScheduleWeekRange);
  }

  const weekRangeBtn = document.getElementById("weekRangeBtn");
  const weekRangeModal = document.getElementById("weekRangeModal");
  const closeWeekRangeModal = document.getElementById("closeWeekRangeModal");

  const closeWeekRangeModalFn = () => {
    if (weekRangeModal) weekRangeModal.style.display = "none";
  };

  if (weekRangeBtn && weekRangeModal) {
    weekRangeBtn.addEventListener("click", () => {
      weekRangeModal.style.display = "block";
    });
    weekRangeModal.addEventListener("click", (e) => {
      if (e.target === weekRangeModal) closeWeekRangeModalFn();
    });
  }
  if (closeWeekRangeModal) {
    closeWeekRangeModal.addEventListener("click", closeWeekRangeModalFn);
  }
});

const CLASS_RANGE_STORAGE_KEY = "classRangeFilter";
const SHOW_ATTENDANCE_STATS_KEY = "showAttendanceStats";

function getShowAttendanceStats() {
  try {
    const val = localStorage.getItem(SHOW_ATTENDANCE_STATS_KEY);
    return val === null ? true : val === "true";
  } catch (_) {
    return true;
  }
}

function setShowAttendanceStats(enabled) {
  try {
    localStorage.setItem(SHOW_ATTENDANCE_STATS_KEY, enabled ? "true" : "false");
  } catch (_) {}
}
window.getShowAttendanceStats = getShowAttendanceStats;
window.setShowAttendanceStats = setShowAttendanceStats;

function getClassRangeFilter() {
  try {
    const saved = localStorage.getItem(CLASS_RANGE_STORAGE_KEY);
    return CLASS_RANGE_MODES.includes(saved) ? saved : "all";
  } catch (_) {
    return "all";
  }
}

function setClassRangeFilter(mode) {
  try {
    localStorage.setItem(CLASS_RANGE_STORAGE_KEY, mode);
  } catch (_) {}
}

/** Tints the Lọc button while a range is hiding part of the timetable. */
function syncClassFilterButton() {
  const btn = document.getElementById("scheduleFilterBtn");
  if (btn) btn.classList.toggle("action-btn--filtering", getClassRangeFilter() !== "all");
}

function persistClassSchedule(jsonString) {
  try {
    localStorage.setItem("classSchedule", jsonString);
  } catch (_) {}
  mirrorClassScheduleToStorage(jsonString);
}

function isStudentGradeUrl(url) {
  return typeof url === "string" && (
    /StudentGrade/i.test(url) ||
    /GradeReport/i.test(url) ||
    /\/Grade(\/|\.|$)/i.test(url) ||
    /\/Report\/Grade/i.test(url) ||
    /academic-report/i.test(url) ||
    /courseId=/i.test(url) ||
    /Diem/i.test(url)
  );
}

/** Tab StudentGrade / GradeReport (có thể không phải tab đang focus). */
function findStudentGradeTab(done) {
  if (typeof chrome === "undefined" || !chrome.tabs) {
    done(new Error("no-chrome-tabs"), null);
    return;
  }
  chrome.tabs.query({ url: "*://fap.fpt.edu.vn/*" }, (candidates) => {
    const list = (candidates || []).filter((t) => t.id && isStudentGradeUrl(t.url || ""));
    if (list.length) {
      const preferred = list.find((t) => t.active) || list[0];
      done(null, preferred);
      return;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = tabs && tabs[0];
      if (t && t.id && isStudentGradeUrl(t.url || "")) {
        done(null, t);
        return;
      }
      done(new Error("no-grade-tab"), null);
    });
  });
}

function isScheduleOfWeekUrl(url) {
  return typeof url === "string" && (/WeeklyTimetable/i.test(url) || /ScheduleOfWeek\.aspx/i.test(url));
}

/** Tab ScheduleOfWeek / WeeklyTimetable (có thể không phải tab đang focus). */
function findScheduleOfWeekTab(done) {
  chrome.tabs.query({ url: "*://fap.fpt.edu.vn/*" }, (candidates) => {
    const list = (candidates || []).filter((t) => t.id && isScheduleOfWeekUrl(t.url || ""));
    if (list.length) {
      const preferred = list.find((t) => t.active) || list[0];
      done(null, preferred);
      return;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = tabs && tabs[0];
      if (t && t.id && isScheduleOfWeekUrl(t.url || "")) {
        done(null, t);
        return;
      }
      done(new Error("no-schedule-tab"), null);
    });
  });
}

let weekRangeSyncInProgress = false;

function fillWeekRangeSelectOptions(weeks, defaultSelectedIdx) {
  const startSel = document.getElementById("weekRangeStart");
  const endSel = document.getElementById("weekRangeEnd");
  const syncBtn = document.getElementById("syncWeekRangeBtn");
  if (!startSel || !endSel) return;
  startSel.replaceChildren();
  endSel.replaceChildren();
  weeks.forEach((w) => {
    const o1 = document.createElement("option");
    o1.value = String(w.index);
    o1.textContent = w.label || `Tuần ${w.index + 1}`;
    o1.dataset.weekVal = w.value || "";
    o1.dataset.refDate = w.refDate || w.startDate || "";
    o1.dataset.startDate = w.startDate || w.refDate || "";
    o1.dataset.endDate = w.endDate || "";
    startSel.appendChild(o1);

    const o2 = document.createElement("option");
    o2.value = String(w.index);
    o2.textContent = w.label || `Tuần ${w.index + 1}`;
    o2.dataset.weekVal = w.value || "";
    o2.dataset.refDate = w.refDate || w.startDate || "";
    o2.dataset.startDate = w.startDate || w.refDate || "";
    o2.dataset.endDate = w.endDate || "";
    endSel.appendChild(o2);
  });
  if (weeks.length) {
    let sIdx = 0;
    let eIdx = weeks.length - 1;
    if (typeof defaultSelectedIdx === "number" && defaultSelectedIdx >= 0 && defaultSelectedIdx < weeks.length) {
      sIdx = Math.max(0, defaultSelectedIdx - 2);
      eIdx = Math.min(weeks.length - 1, defaultSelectedIdx + 8);
    }
    startSel.selectedIndex = sIdx;
    endSel.selectedIndex = eIdx;
    startSel.disabled = false;
    endSel.disabled = false;
    if (syncBtn) syncBtn.disabled = false;
  }
}

function setWeekRangeStatus(text, show) {
  const el = document.getElementById("weekRangeStatus");
  if (!el) return;
  el.textContent = text || "";
  el.hidden = !show;
}

function setWeekRangeControlsDisabled(disabled) {
  ["loadWeekOptionsBtn", "syncWeekRangeBtn", "weekRangeStart", "weekRangeEnd"].forEach((id) => {
    const n = document.getElementById(id);
    if (n) n.disabled = disabled;
  });
}

function handleLoadWeekScheduleOptions() {
  findScheduleOfWeekTab(async (err, tab) => {
    if (err || !tab || !tab.id) {
      const open = await showConfirm(
        "Chưa có tab Lịch tuần FAP. Mở https://fap.fpt.edu.vn/WeeklyTimetable ?",
        { okLabel: "Mở FAP" }
      );
      if (open) {
        chrome.tabs.create({ url: "https://fap.fpt.edu.vn/WeeklyTimetable", active: true });
      }
      return;
    }
    setWeekRangeStatus("Đang đọc danh sách tuần…", true);
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }, () => {
      if (chrome.runtime.lastError) {
        setWeekRangeStatus("", false);
        showError("Không đọc được trang. Tải lại FAP rồi mở lại popup.");
        return;
      }
      chrome.tabs.sendMessage(tab.id, { action: "getWeekScheduleControls" }, (res) => {
        if (chrome.runtime.lastError) {
          setWeekRangeStatus("", false);
          showError("Không gửi được yêu cầu tới trang. Tải lại FAP.");
          return;
        }
        if (!res || !res.ok) {
          setWeekRangeStatus("", false);
          if (res && res.loginRequired) {
            chrome.tabs.create({ url: "https://fap.fpt.edu.vn/Default.aspx", active: true });
            showError("Bạn cần đăng nhập FAP. Đã mở trang đăng nhập.");
          } else {
            showError("Không thấy danh sách tuần. Đảm bảo bạn đang ở trang Lịch tuần FAP.");
          }
          return;
        }
        if (!res.weeks || !res.weeks.length) {
          setWeekRangeStatus("", false);
          showError("Danh sách tuần trống.");
          return;
        }
        fillWeekRangeSelectOptions(res.weeks, res.weekIndex);
        window._fapWeeksMeta = res.weeks;
        window._fapIsNewUi = Boolean(res.isNewUi);
        if (res.isNewUi) {
          const curLabel = (res.weeks[res.weekIndex] && res.weeks[res.weekIndex].label) || "tuần hiện tại";
          setWeekRangeStatus(`FAP mới: Đã tải ${res.weeks.length} tuần (${curLabel}). Chọn khoảng rồi nhấn Đồng bộ.`, true);
        } else {
          setWeekRangeStatus(`Đã tải ${res.weeks.length} tuần. Chọn khoảng rồi nhấn Đồng bộ.`, true);
        }
      });
    });
  });
}

function handleSyncClassScheduleWeekRange() {
  if (weekRangeSyncInProgress) return;
  const startSel = document.getElementById("weekRangeStart");
  const endSel = document.getElementById("weekRangeEnd");
  if (!startSel || !endSel || startSel.disabled) {
    showError("Nhấn «Tải tuần» trước khi đồng bộ khoảng.");
    return;
  }
  let startIdx = parseInt(startSel.value, 10);
  let endIdx = parseInt(endSel.value, 10);
  if (Number.isNaN(startIdx) || Number.isNaN(endIdx)) {
    showError("Tuần không hợp lệ.");
    return;
  }
  if (startIdx > endIdx) {
    const t = startIdx;
    startIdx = endIdx;
    endIdx = t;
  }

  const weekLabels = [];
  for (let i = 0; i < startSel.options.length; i++) {
    weekLabels.push((startSel.options[i].textContent || "").trim());
  }

  findScheduleOfWeekTab(async (err, tab) => {
    if (err || !tab || !tab.id) {
      const open = await showConfirm(
        "Cần tab Lịch tuần FAP để đồng bộ. Mở WeeklyTimetable?",
        { okLabel: "Mở FAP" }
      );
      if (open) {
        chrome.tabs.create({ url: "https://fap.fpt.edu.vn/WeeklyTimetable", active: true });
      }
      return;
    }

    const tabId = tab.id;
    const total = endIdx - startIdx + 1;
    weekRangeSyncInProgress = true;
    setWeekRangeControlsDisabled(true);
    setWeekRangeStatus(
      `Đang đồng bộ ${total} tuần trong nền… Bạn có thể đóng popup; mở lại khi xong.`,
      true
    );

    const seedJson = localStorage.getItem("classSchedule") || "[]";
    let weeksMeta = window._fapWeeksMeta;
    if ((!weeksMeta || !weeksMeta.length) && startSel.options.length > 0) {
      weeksMeta = [];
      for (let i = 0; i < startSel.options.length; i++) {
        const opt = startSel.options[i];
        weeksMeta.push({
          index: i,
          value: opt.dataset.weekVal || opt.dataset.refDate || opt.value,
          weekVal: opt.dataset.weekVal || "",
          refDate: opt.dataset.refDate || "",
          startDate: opt.dataset.startDate || "",
          endDate: opt.dataset.endDate || "",
          label: (opt.textContent || "").trim()
        });
      }
    }
    const isNewUi = Boolean(window._fapIsNewUi) || (tab && tab.url && /WeeklyTimetable/i.test(tab.url));

    const payload = {
      type: "START_WEEK_RANGE_SYNC",
      tabId,
      startIdx,
      endIdx,
      weekLabels,
      seedJson,
      isNewUi,
      weeksMeta: weeksMeta || null
    };
    function sendStartWeekRangeSync(attempt) {
      chrome.runtime.sendMessage(payload, (resp) => {
        const err = chrome.runtime.lastError;
        if (err && attempt < 2) {
          setTimeout(() => sendStartWeekRangeSync(attempt + 1), 250);
          return;
        }
        if (err || !resp || !resp.ok) {
          weekRangeSyncInProgress = false;
          setWeekRangeControlsDisabled(false);
          setWeekRangeStatus("", false);
          showError(
            "Không khởi chạy được đồng bộ nền: " +
              (err && err.message ? err.message : "unknown") +
              ". Xem chi tiết ở chrome://extensions → Service worker → Inspect."
          );
        }
      });
    }
    sendStartWeekRangeSync(0);
  });
}

function applyWeekRangeSyncDoneFromBackground(msg) {
  weekRangeSyncInProgress = false;
  setWeekRangeControlsDisabled(false);
  if (msg.mergedJson) {
    persistClassSchedule(msg.mergedJson);
    try {
      const merged = JSON.parse(msg.mergedJson);
      window.renderClassSchedule && window.renderClassSchedule(merged);
    } catch (e) { /* no-op */ }
  }
  try {
    document.getElementById("scheduleTabBtn")?.click();
  } catch (e) { /* no-op */ }
  if (msg.toastText) {
    showToast(msg.toastText, 4200);
  }
  if (msg.statusText) {
    setWeekRangeStatus(msg.statusText, true);
  }
}

function pollWeekRangeSyncUntilIdle() {
  const loc = getChromeStorageLocal();
  if (!loc) return;
  let ticks = 0;
  const iv = setInterval(() => {
    ticks += 1;
    if (ticks > 600) {
      clearInterval(iv);
      weekRangeSyncInProgress = false;
      setWeekRangeControlsDisabled(false);
      setWeekRangeStatus("", false);
      return;
    }
    try {
      loc.get(["weekRangeSyncRunning", "classSchedule", "weekRangeLastSummary", "weekRangeProgress"], (r) => {
        if (chrome.runtime.lastError) return;
        if (r.weekRangeSyncRunning) {
          if (r.weekRangeProgress) {
            setWeekRangeStatus(`Đang đồng bộ tuần ${r.weekRangeProgress.current}/${r.weekRangeProgress.total}: ${r.weekRangeProgress.label}…`, true);
          }
          return;
        }
        clearInterval(iv);
        if (r.classSchedule) {
          const cur = localStorage.getItem("classSchedule");
          if (cur !== r.classSchedule) {
            persistClassSchedule(r.classSchedule);
            try {
              window.renderClassSchedule && window.renderClassSchedule(JSON.parse(r.classSchedule));
            } catch (e) { /* no-op */ }
          }
        }
        if (r.weekRangeLastSummary) {
          if (r.weekRangeLastSummary.toastText) {
            showToast(r.weekRangeLastSummary.toastText, 4200);
          }
          if (r.weekRangeLastSummary.statusText) {
            setWeekRangeStatus(r.weekRangeLastSummary.statusText, true);
          }
          try {
            loc.remove(["weekRangeLastSummary"]);
          } catch (_) {}
        }
        weekRangeSyncInProgress = false;
        setWeekRangeControlsDisabled(false);
      });
    } catch (_) {
      clearInterval(iv);
      weekRangeSyncInProgress = false;
      setWeekRangeControlsDisabled(false);
    }
  }, 500);
}

function handleSyncClassSchedule() {
  showToast("Đang sync lịch học...", 1500);

  findScheduleOfWeekTab(async (err, tab) => {
    if (err || !tab || !tab.id) {
      const open = await showConfirm("Cần trang Lịch tuần (WeeklyTimetable). Mở FAP?", { okLabel: "Mở FAP" });
      if (open) {
        chrome.tabs.create({ url: "https://fap.fpt.edu.vn/WeeklyTimetable", active: true });
      }
      return;
    }

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    }, (results) => {
      if (chrome.runtime.lastError) {
        console.error("Script injection failed:", chrome.runtime.lastError);
        showError("Không truy cập được trang để đồng bộ lịch học. Tải lại trang rồi thử lại.");
        return;
      }

      chrome.tabs.sendMessage(tab.id, { action: "extractWeeklySchedule" }, function (response) {
        if (chrome.runtime.lastError) {
          console.error("extractWeeklySchedule message failed:", chrome.runtime.lastError);
          showError("Có lỗi khi đồng bộ lịch học. Thử lại.");
          return;
        }
        
        if (!response || !response.success) {
          if (response && response.loginRequired) {
            // Open login page and focus it so user can sign in
            chrome.tabs.create({ url: 'https://fap.fpt.edu.vn/Default.aspx', active: true });
            showError("Bạn cần đăng nhập FAP. Đăng nhập rồi mở lại popup.");
            return;
          }
          console.error("Weekly schedule extraction failed");
          showError("Không đọc được bảng lịch học. Kiểm tra: đang ở trang Lịch tuần, trang đã tải xong, và đã đăng nhập.");
          return;
        }
        
        const newEvents = response.schedule || [];
        
        if (newEvents.length === 0) {
          showError("Tuần này không có lịch học nào, hoặc trang chưa tải xong.");
          return;
        }
        
        const existingData = localStorage.getItem("classSchedule");
        let allSchedule = [];
        
        if (existingData) {
          try {
            allSchedule = JSON.parse(existingData);
          } catch (e) {
            console.error("Error parsing existing schedule:", e);
            allSchedule = [];
          }
        }
        
        // Replace the weeks this sync covers so cancelled or moved classes disappear, unless
        // some cells were unreadable (an incomplete sync must not look like a cancellation).
        let uniqueNewEvents;
        let mergedSchedule;
        if (!(response.skipped > 0) && typeof replaceCoveredWeeks === "function") {
          const replaced = replaceCoveredWeeks(allSchedule, newEvents);
          uniqueNewEvents = replaced.uniqueNewEvents;
          mergedSchedule = replaced.merged;
          const scheduleChanges = detectScheduleChanges(replaced.replacedOld, newEvents, new Date());
          if (scheduleChanges.length > 0) {
            try { chrome.runtime.sendMessage({ type: "SCHEDULE_CHANGES", changes: scheduleChanges }).catch(() => {}); } catch (_) {}
          }
        } else {
          ({ uniqueNewEvents, merged: mergedSchedule } = mergeNewClassEventsInto(allSchedule, newEvents));
        }
        allSchedule = mergedSchedule;
        persistClassSchedule(JSON.stringify(allSchedule));
        // Re-render UI for the schedule tab
        window.renderClassSchedule && window.renderClassSchedule(allSchedule);
        // Chuyển sang tab Lịch học và hiện toast thay vì alert
        try {
          document.getElementById('scheduleTabBtn')?.click();
        } catch (e) { /* no-op */ }
        const skipped = response.skipped || 0;
        if (skipped > 0) {
          showError(`Đồng bộ xong nhưng bỏ qua ${skipped} ô không đọc được — FAP có thể đã đổi giao diện.`);
        } else {
          showToast(`Đã đồng bộ lịch học! Mới: ${uniqueNewEvents.length} • Tổng: ${allSchedule.length}`, 2600);
        }
      });
    });
  });
}

function handleDownloadClassSchedule() {
  const storedData = localStorage.getItem("classSchedule");
  
  if (!storedData) {
    showError("Chưa có dữ liệu lịch học. Đồng bộ lịch học trước đã.");
    return;
  }

  let schedule;
  try {
    schedule = JSON.parse(storedData);
  } catch (e) {
    console.error("Parse stored schedule failed:", e);
    showError("Dữ liệu lịch học bị lỗi. Đồng bộ lại.");
    return;
  }

  if (!schedule || !schedule.length) {
    showError("Không có lịch học nào để tải.");
    return;
  }

  // Create ICS content for class schedule
  const cal = createClassCalendar();
  
  // Group events by date to identify first slots
  const eventsByDate = {};
  
  // First pass: group events by date
  schedule.forEach(event => {
    if (event.rawDate) {
      const dateKey = `${event.rawDate.day}-${event.rawDate.month}-${event.rawDate.year}`;
      if (!eventsByDate[dateKey]) {
        eventsByDate[dateKey] = [];
      }
      eventsByDate[dateKey].push(event);
    }
  });
  
  // Second pass: sort events by time and mark first slots
  Object.keys(eventsByDate).forEach(dateKey => {
    // Sort events by start time
    eventsByDate[dateKey].sort((a, b) => {
      if (a.rawDate.startHour !== b.rawDate.startHour) {
        return a.rawDate.startHour - b.rawDate.startHour;
      }
      return a.rawDate.startMinute - b.rawDate.startMinute;
    });
    
    // Mark the first event of the day
    if (eventsByDate[dateKey].length > 0) {
      eventsByDate[dateKey][0].isFirstSlot = true;
    }
  });
  
  // Add events to calendar
  schedule.forEach(event => {
    cal.addEvent(
      event.title,
      event.description || '',
      event.location || '',
      event,
      event.isFirstSlot // Pass the flag that identifies if it's the first slot of the day
    );
  });

  const blob = new Blob([cal.build()], { type: 'text/calendar' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.setAttribute('href', url);
  a.setAttribute('download', 'lich-hoc.ics');
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);

  showToast(`Đã tải ${schedule.length} tiết học. Chúc bạn học tốt!`, 2600);
}

async function handleClearClassSchedule() {
  const proceed = await showConfirm(
    "Bạn có chắc chắn muốn xoá toàn bộ lịch học đã lưu?",
    { title: "Xoá lịch học", okLabel: "Xoá", danger: true }
  );
  if (!proceed) return;
  try {
    localStorage.removeItem("classSchedule");
    try {
      const loc = getChromeStorageLocal();
      if (loc) loc.remove(["classSchedule"]);
    } catch (_) {}
    // Re-render empty state immediately
    try {
      window.renderClassSchedule && window.renderClassSchedule([]);
    } catch (_) {}
    // Ensure we are on the Lịch học tab so user sees the change
    try { document.getElementById('scheduleTabBtn')?.click(); } catch (_) {}
    showToast('Đã xoá toàn bộ lịch học');
  } catch (e) {
    console.error("Error clearing class schedule:", e);
    showError("Có lỗi khi xoá lịch học.");
  }
}

async function handleClearExamSchedule() {
  const proceed = await showConfirm(
    "Bạn có chắc chắn muốn xoá toàn bộ lịch thi đã lưu?",
    { title: "Xoá lịch thi", okLabel: "Xoá", danger: true }
  );
  if (!proceed) return;
  try {
    localStorage.removeItem("examSchedule");
    try {
      const loc = getChromeStorageLocal();
      if (loc) {
        loc.remove(["examSchedule"], () => {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARMS" }).catch(() => {});
          }
        });
      }
    } catch (_) {}
    renderExamList([]);
    showToast("Đã xoá toàn bộ lịch thi");
  } catch (e) {
    console.error("Error clearing exam schedule:", e);
    showError("Có lỗi khi xoá lịch thi.");
  }
}

async function deleteSingleExam(examToDelete) {
  try {
    const raw = localStorage.getItem("examSchedule");
    if (!raw) return;
    let list = JSON.parse(raw);
    if (!Array.isArray(list)) return;

    const targetStart = new Date(examToDelete.start).getTime();
    const targetTitle = (examToDelete.title || "").trim();
    const targetTag = (examToDelete.tag || "").trim();
    const targetLoc = (examToDelete.location || "").trim();
    const targetDesc = (examToDelete.description || "").trim();

    const idx = list.findIndex((item) => {
      const itemStart = new Date(item.start).getTime();
      return (
        (item.title || "").trim() === targetTitle &&
        itemStart === targetStart &&
        (item.tag || "").trim() === targetTag &&
        (item.location || "").trim() === targetLoc &&
        (item.description || "").trim() === targetDesc
      );
    });

    if (idx !== -1) {
      list.splice(idx, 1);
    } else {
      const fallbackIdx = list.findIndex((item) => {
        const itemStart = new Date(item.start).getTime();
        return (item.title || "").trim() === targetTitle && itemStart === targetStart;
      });
      if (fallbackIdx !== -1) list.splice(fallbackIdx, 1);
    }

    localStorage.setItem("examSchedule", JSON.stringify(list));
    mirrorExamScheduleToStorage(list);
    renderExamList(list);
    showToast(`Đã xoá lịch thi môn ${examToDelete.title}`);
  } catch (err) {
    console.error("Error deleting single exam:", err);
    showError("Có lỗi khi xoá lịch thi.");
  }
}

function tryAutoRefreshAttendance() {
  // Only run if we already have some schedule stored (to match against)
  const stored = localStorage.getItem("classSchedule");
  if (!stored) return;
  let saved;
  try { saved = JSON.parse(stored); } catch { return; }
  if (!Array.isArray(saved) || saved.length === 0) return;

  const keyOf = (ev) => {
    if (ev && ev.rawDate) {
      const rd = ev.rawDate;
      const code = (ev.code || (ev.title || "").split(/\s*-\s*/)[0] || ev.title || "").trim().toUpperCase();
      const y = Number(rd.year);
      const m = Number(rd.month);
      const d = Number(rd.day);
      const sh = Number(rd.startHour);
      const sm = Number(rd.startMinute);
      return `${code}__${y}-${m}-${d}__${sh}:${sm}`;
    }
    return null;
  };

  const extractFromTab = (tabId, onDone) => {
    chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }, () => {
      if (chrome.runtime.lastError) {
        console.warn('Skip auto attendance refresh (inject error):', chrome.runtime.lastError.message);
        return onDone && onDone(false);
      }
      chrome.tabs.sendMessage(tabId, { action: 'extractWeeklySchedule' }, function (response) {
        if (chrome.runtime.lastError || !response || !response.success || !Array.isArray(response.schedule)) {
          if (response && response.loginRequired) {
            try {
              chrome.tabs.update(tabId, { active: true });
            } catch (_) {}
            showToast('Cần đăng nhập FAP để cập nhật điểm danh. Vui lòng đăng nhập rồi mở lại popup.', 3000);
          }
          return onDone && onDone(false);
        }
        const fresh = response.schedule;
        const freshMap = new Map();
        fresh.forEach(ev => { const k = keyOf(ev); if (k) freshMap.set(k, ev); });

        let updated = 0;
        const merged = saved.map(ev => {
          const k = keyOf(ev);
          if (!k) return ev;
          const f = freshMap.get(k);
          if (!f) return ev;
          const attStatus = f.attendanceStatus || f.attendance_status || null;
          const attColor = f.attendanceColor || f.attendance_color || null;
          if (attStatus && attStatus !== ev.attendanceStatus) { ev.attendanceStatus = attStatus; updated++; }
          if (attColor && attColor !== ev.attendanceColor) { ev.attendanceColor = attColor; }
          return ev;
        });

        if (updated > 0) {
          persistClassSchedule(JSON.stringify(merged));
          try { window.renderClassSchedule && window.renderClassSchedule(merged); } catch (_) {}
        }
        onDone && onDone(true);
      });
    });
  };

  findScheduleOfWeekTab((err, tab) => {
    if (err || !tab || !tab.id) return;
    extractFromTab(tab.id);
  });
}

function autoSyncSchedule() {
  const loadingEl = document.getElementById("examSyncLoading");
  const errorEl = document.getElementById("examSyncError");
  const up = document.getElementById("upcomingExams");
  const co = document.getElementById("completedExams");
  if (up) while (up.firstChild) up.removeChild(up.firstChild);
  if (co) while (co.firstChild) co.removeChild(co.firstChild);

  if (loadingEl) loadingEl.hidden = false;
  if (errorEl) errorEl.hidden = true;

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (!tabs || !tabs[0]) {
      if (loadingEl) loadingEl.hidden = true;
      return;
    }
    
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      files: ["content.js"]
    }, (results) => {
      if (chrome.runtime.lastError) {
        console.error('Script injection failed:', chrome.runtime.lastError);
        if (loadingEl) loadingEl.hidden = true;
        if (errorEl) errorEl.hidden = false;
        return;
      }
      
      chrome.tabs.sendMessage(tabs[0].id, { action: "extractSchedule" }, function (response) {
        if (loadingEl) loadingEl.hidden = true;
        if (chrome.runtime.lastError) {
          console.error('Message sending failed:', chrome.runtime.lastError);
          if (errorEl) errorEl.hidden = false;
          return;
        }
        if (!response || !response.events) {
          if (errorEl) errorEl.hidden = false;
          return;
        }
        localStorage.setItem("examSchedule", JSON.stringify(response.events));
        mirrorExamScheduleToStorage(response.events);

        renderExamList(response.events);
      });
    });
  });
}

/** Mirrors the "Lịch học (n)" count that renderClassSchedule puts on its own tab. */
function setExamTabCount(upcomingCount) {
  const label = document.getElementById("upcomingTab")?.querySelector(".tab-btn__text");
  if (label) label.textContent = upcomingCount ? `Kỳ thi (${upcomingCount})` : "Kỳ thi";
}

function renderExamList(events) {
  if (!Array.isArray(events)) events = [];
  const upcomingContainer = document.getElementById("upcomingExams");
  const completedContainer = document.getElementById("completedExams");
  const loadingEl = document.getElementById("examSyncLoading");
  const errorEl = document.getElementById("examSyncError");
  
  if (loadingEl) loadingEl.hidden = true;
  if (errorEl) errorEl.hidden = true;
  
  if (!upcomingContainer || !completedContainer) return;

  // Clear both containers safely
  while (upcomingContainer.firstChild) {
    upcomingContainer.removeChild(upcomingContainer.firstChild);
  }
  while (completedContainer.firstChild) {
    completedContainer.removeChild(completedContainer.firstChild);
  }

  // Insert column headings
  const upHead = document.createElement("div"); upHead.className = "split-heading"; upHead.textContent = "Chưa thi";
  upcomingContainer.appendChild(upHead);
  const compHead = document.createElement("div"); compHead.className = "split-heading"; compHead.textContent = "Đã thi";
  completedContainer.appendChild(compHead);
  
  if (!events.length) {
    const emptyDiv = document.createElement("div");
    emptyDiv.className = "exam-list-hint";
    emptyDiv.textContent = "Không có lịch thi nào.";
    upcomingContainer.appendChild(emptyDiv);
    setExamTabCount(0);
    return;
  }

  // Separate upcoming and completed exams
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  const upcomingExams = [];
  const completedExams = [];

  events.forEach(e => {
    const start = new Date(e.start);
    const examDate = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const diffTime = examDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      completedExams.push(e);
    } else {
      upcomingExams.push(e);
    }
  });

  // Update headings with counts
  upHead.textContent = `Chưa thi (${upcomingExams.length})`;
  compHead.textContent = `Đã thi (${completedExams.length})`;
  setExamTabCount(upcomingExams.length);

  // Render upcoming exams
  if (upcomingExams.length === 0) {
    const emptyDiv = document.createElement("div");
    emptyDiv.className = "exam-list-hint";
    emptyDiv.textContent = "Không có kỳ thi nào sắp tới.";
    upcomingContainer.appendChild(emptyDiv);
  } else {
    upcomingExams.forEach(e => {
      const examItem = createExamItem(e);
      upcomingContainer.appendChild(examItem);
    });
  }

  // Render completed exams
  if (completedExams.length === 0) {
    const emptyDiv = document.createElement("div");
    emptyDiv.className = "exam-list-hint";
    emptyDiv.textContent = "Không có kỳ thi nào đã hoàn thành.";
    completedContainer.appendChild(emptyDiv);
  } else {
    completedExams.forEach(e => {
      const examItem = createExamItem(e);
      completedContainer.appendChild(examItem);
    });
  }

  // Apply filters after rendering
  setTimeout(() => {
    if (window.applyFilters) {
      window.applyFilters();
    }
  }, 100);
}

function createExamItem(e) {
  const desc = (e.description + ' ' + e.title).toLowerCase();
  const examType = (e.examType || "").toLowerCase();
  const tagType = (() => {
    if (e.tag) {
      return e.tag; 
    }
    
    const tag = (examType || "").toLowerCase();
    if (tag.includes("2ndfe") || desc.includes("2ndfe") || desc.includes("2nd fe")) return "2NDFE";
    if (tag.includes("2ndpe") || desc.includes("2ndpe") || desc.includes("2nd pe")) return "2NDPE";
    if (tag === "pe" || desc.includes("practical_exam") || desc.includes("project presentation")) return "PE";
    if (tag === "fe" || desc.includes("fe") || desc.includes("final") || desc.includes("multiple_choices") || desc.includes("speaking")) return "FE";
    return null;
  })();

  const row = document.createElement("div");
  row.className = "exam-item";

  const start = new Date(e.start);
  const end = new Date(e.end);
  const formatTime = d => d.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });
  const formatDate = d => d.toLocaleDateString("vi-VN");

  // Calculate days remaining
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const examDate = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  const diffTime = examDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  // Create exam card structure safely
  const examCard = document.createElement("div");
  examCard.className = "exam-card";

  const examHeader = document.createElement("div");
  examHeader.className = "exam-header";

  const examTitle = document.createElement("div");
  examTitle.className = "exam-title";

  const codeSpan = document.createElement("span");
  codeSpan.className = "exam-code";
  codeSpan.textContent = e.title;
  examTitle.appendChild(codeSpan);

  const tagGroup = document.createElement("span");
  tagGroup.className = "exam-title__tags";

  if (tagType) {
    const tagSpan = document.createElement("span");
    tagSpan.className = "tag";
    if (tagType === "2NDFE") {
      tagSpan.classList.add("secondfe");
      tagSpan.textContent = "2NDFE";
    } else if (tagType === "2NDPE") {
      tagSpan.classList.add("secondpe");
      tagSpan.textContent = "2NDPE";
    } else if (tagType === "PE") {
      tagSpan.classList.add("pe");
      tagSpan.textContent = "PE";
    } else if (tagType === "FE") {
      tagSpan.classList.add("fe");
      tagSpan.textContent = "FE";
    }
    tagGroup.appendChild(tagSpan);
  }

  const countdownSpan = document.createElement("span");
  countdownSpan.className = "tag countdown";
  if (diffDays < 0) {
    countdownSpan.classList.add("past");
    countdownSpan.textContent = "Đã thi";
  } else if (diffDays === 0) {
    countdownSpan.classList.add("today");
    countdownSpan.textContent = "Hôm nay";
  } else if (diffDays === 1) {
    countdownSpan.classList.add("tomorrow");
    countdownSpan.textContent = "Ngày mai";
  } else if (diffDays <= 3) {
    countdownSpan.classList.add("urgent");
    countdownSpan.textContent = "Còn " + diffDays + " ngày";
  } else {
    countdownSpan.classList.add("future");
    countdownSpan.textContent = "Còn " + diffDays + " ngày";
  }
  tagGroup.appendChild(countdownSpan);

  const deleteBtn = document.createElement("button");
  deleteBtn.type = "button";
  deleteBtn.className = "exam-delete-btn";
  deleteBtn.title = `Xoá lịch thi môn ${e.title}`;
  deleteBtn.setAttribute("aria-label", `Xoá lịch thi môn ${e.title}`);
  deleteBtn.innerHTML = '<svg class="icon" aria-hidden="true"><use href="#icon-trash"/></svg>';
  deleteBtn.addEventListener("click", async (ev) => {
    ev.stopPropagation();
    const dateStr = formatDate(start);
    const ok = await showConfirm(`Bạn có chắc chắn muốn xoá lịch thi môn ${e.title} (${dateStr})?`, {
      title: "Xoá lịch thi",
      okLabel: "Xoá",
      danger: true
    });
    if (!ok) return;
    deleteSingleExam(e);
  });
  tagGroup.appendChild(deleteBtn);

  examTitle.appendChild(tagGroup);

  examHeader.appendChild(examTitle);
  examCard.appendChild(examHeader);

  // Create exam details safely
  const examDetail = document.createElement("div");
  examDetail.className = "exam-detail";

  const createDetailLine = (label, value) => {
    const line = document.createElement("div");
    line.className = "meta-row";
    const lab = document.createElement("span");
    lab.className = "meta-label";
    lab.textContent = `${label}:`;
    const val = document.createElement("span");
    val.className = "meta-value";
    val.textContent = value;
    line.appendChild(lab);
    line.appendChild(val);
    return line;
  };

  examDetail.appendChild(createDetailLine("Phương thức", e.description || "Chưa rõ"));
  examDetail.appendChild(createDetailLine("Phòng", e.location || "Chưa rõ"));
  examDetail.appendChild(createDetailLine("Ngày thi", formatDate(start)));
  examDetail.appendChild(createDetailLine("Thời gian", formatTime(start) + " - " + formatTime(end)));

  examCard.appendChild(examDetail);

  row.appendChild(examCard);

  return row;
}

/** kind: "info" (default) | "error" — errors are tinted red and linger longer. */
function showToast(message, duration = 1800, kind = "info") {
  let toast = document.getElementById('popupToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'popupToast';
    toast.className = 'popup-toast';
    document.body.appendChild(toast);
  }
  toast.classList.toggle('popup-toast--error', kind === 'error');
  toast.textContent = message;
  const triggerShow = () => { toast.style.opacity = '1'; };
  if (typeof requestAnimationFrame === "function") {
    requestAnimationFrame(triggerShow);
  } else {
    setTimeout(triggerShow, 0);
  }
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => {
    toast.style.opacity = '0';
  }, duration);
}

function showError(message) {
  showToast(message, 4200, "error");
}

/**
 * Promise-based stand-in for window.confirm(), styled like the rest of the popup instead of
 * a native browser dialog. Resolves true/false; never rejects.
 */
function showConfirm(message, opts = {}) {
  const { title = "Xác nhận", okLabel = "Đồng ý", danger = false } = opts;
  const modal = document.getElementById("confirmModal");
  const titleEl = document.getElementById("confirmModalTitle");
  const msgEl = document.getElementById("confirmModalMessage");
  const okBtn = document.getElementById("confirmModalOk");
  const cancelBtn = document.getElementById("confirmModalCancel");
  const closeBtn = document.getElementById("closeConfirmModal");

  titleEl.textContent = title;
  msgEl.textContent = message;
  okBtn.textContent = okLabel;
  okBtn.classList.toggle("danger-btn", danger);
  modal.style.display = "block";

  return new Promise((resolve) => {
    const settle = (result) => {
      modal.style.display = "none";
      okBtn.removeEventListener("click", onOk);
      cancelBtn.removeEventListener("click", onCancel);
      closeBtn.removeEventListener("click", onCancel);
      modal.removeEventListener("click", onBackdrop);
      resolve(result);
    };
    const onOk = () => settle(true);
    const onCancel = () => settle(false);
    const onBackdrop = (e) => { if (e.target === modal) settle(false); };

    okBtn.addEventListener("click", onOk);
    cancelBtn.addEventListener("click", onCancel);
    closeBtn.addEventListener("click", onCancel);
    modal.addEventListener("click", onBackdrop);
  });
}
