/* importScripts is wrapped so a load failure cannot abort evaluation of this file: the
   onMessage listener at the bottom must register no matter what, otherwise the popup only
   ever sees "Receiving end does not exist" with no clue why. */
try {
  importScripts("lib/schedule.js");
} catch (e) {
  console.error("background: could not load lib/schedule.js", e);
}
try {
  importScripts("lib/notifications.js");
} catch (e) {
  console.error("background: could not load lib/notifications.js", e);
}
try {
  importScripts("lib/agenda.js");
} catch (e) {
  console.error("background: could not load lib/agenda.js", e);
}
try {
  importScripts("lib/grades.js");
} catch (e) {
  console.error("background: could not load lib/grades.js", e);
}
function armWaitForTabComplete(tabId, timeoutMs, onDone) {
  let settled = false;
  let timer;
  const listener = (id, info) => {
    if (id !== tabId || info.status !== "complete") return;
    if (settled) return;
    settled = true;
    chrome.tabs.onUpdated.removeListener(listener);
    clearTimeout(timer);
    setTimeout(() => onDone(true), 400);
  };
  chrome.tabs.onUpdated.addListener(listener);
  timer = setTimeout(() => {
    if (settled) return;
    settled = true;
    chrome.tabs.onUpdated.removeListener(listener);
    onDone(false);
  }, timeoutMs);
  return function cancelWait() {
    if (settled) return;
    settled = true;
    chrome.tabs.onUpdated.removeListener(listener);
    clearTimeout(timer);
  };
}

function extractWeeklyScheduleFromTab(tabId, callback) {
  chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
    if (chrome.runtime.lastError) {
      callback(chrome.runtime.lastError.message, null);
      return;
    }
    chrome.tabs.sendMessage(tabId, { action: "extractWeeklySchedule" }, (response) => {
      if (chrome.runtime.lastError) {
        callback(chrome.runtime.lastError.message, null);
        return;
      }
      callback(null, response);
    });
  });
}

function executeFapWeekIndexMain(tabId, weekIndex, callback) {
  chrome.scripting.executeScript(
    {
      target: { tabId },
      world: "MAIN",
      func: (idx) => {
        function weekSelectEl() {
          return (
            document.getElementById("ctl00_mainContent_drpWeek") ||
            document.getElementById("ctl00_mainContent_ddlWeek") ||
            document.querySelector('select[id*="mainContent"][id*="drp"][id*="Week"]') ||
            document.querySelector('select[id*="mainContent"][id*="Week"]') ||
            document.querySelector('select[name*="drpWeek"]') ||
            document.querySelector('select[name*="Week"]')
          );
        }
        const sel = weekSelectEl();
        if (!sel) {
          const isNewUi = !!document.getElementById("weekly-timetable-container") || !!document.querySelector(".weekly-timetable-grid");
          if (isNewUi) {
            return { ok: true, skippedPostback: true };
          }
          return { ok: false, error: "week-select-not-found" };
        }
        if (idx < 0 || idx >= sel.options.length) return { ok: false, error: "bad-index" };
        if (sel.selectedIndex === idx) {
          return { ok: true, skippedPostback: true };
        }
        sel.selectedIndex = idx;
        const oc = sel.getAttribute("onchange") || "";
        const m = oc.match(/__doPostBack\s*\(\s*'([^']*)'\s*,\s*'([^']*)'\s*\)/);
        if (typeof __doPostBack === "function") {
          if (m) __doPostBack(m[1], m[2] !== undefined && m[2] !== null ? m[2] : "");
          else __doPostBack(sel.name, "");
          return { ok: true, skippedPostback: false };
        }
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true, skippedPostback: false, weak: true };
      },
      args: [weekIndex]
    },
    (results) => {
      if (chrome.runtime.lastError) {
        callback(chrome.runtime.lastError.message, null);
        return;
      }
      const r = results && results[0] && results[0].result;
      if (!r || !r.ok) {
        callback((r && r.error) || "unknown", null);
        return;
      }
      callback(null, r);
    }
  );
}

function runWeekRangeSync(tabId, startIdx, endIdx, weekLabels, seedJson, isNewUiOrOnComplete, weeksMetaOrUndefined, maybeOnComplete) {
  let isNewUi = false;
  let weeksMeta = null;
  let onComplete = null;
  if (typeof isNewUiOrOnComplete === "function") {
    onComplete = isNewUiOrOnComplete;
  } else {
    isNewUi = Boolean(isNewUiOrOnComplete);
    weeksMeta = Array.isArray(weeksMetaOrUndefined) ? weeksMetaOrUndefined : null;
    onComplete = maybeOnComplete;
  }

  const lo = Math.min(startIdx, endIdx);
  const hi = Math.max(startIdx, endIdx);
  const total = hi - lo + 1;
  let current = lo;
  let stepIndex = 0;
  const collected = [];
  const failedWeeks = [];
  let skippedCells = 0;

  const labelForWeek = (i) => {
    if (weeksMeta && weeksMeta[i] && weeksMeta[i].label) return weeksMeta[i].label;
    if (weekLabels && weekLabels[i]) return weekLabels[i];
    return `Tuần #${i + 1}`;
  };

  function finish() {
    let allSchedule = [];
    try {
      allSchedule = JSON.parse(typeof seedJson === "string" ? seedJson : "[]");
    } catch (_) {
      allSchedule = [];
    }
    // A sync that skipped unreadable cells is incomplete, so it must not erase stored classes
    // (they would look cancelled). Fall back to the additive merge in that case.
    let uniqueNewEvents;
    let merged;
    let scheduleChanges = [];
    if (skippedCells === 0 && typeof replaceCoveredWeeks === "function") {
      const replaced = replaceCoveredWeeks(allSchedule, collected);
      uniqueNewEvents = replaced.uniqueNewEvents;
      merged = replaced.merged;
      scheduleChanges = detectScheduleChanges(replaced.replacedOld, collected, new Date());
    } else {
      ({ uniqueNewEvents, merged } = mergeNewClassEventsInto(allSchedule, collected));
    }
    const mergedJson = JSON.stringify(merged);
    const failMsg =
      failedWeeks.length > 0
        ? ` • Tuần lỗi: ${failedWeeks.map((f) => f.label).join("; ")}`
        : "";
    const skipMsg = skippedCells > 0 ? ` • Bỏ qua ${skippedCells} ô không đọc được` : "";
    const toastText = `Đồng bộ xong ${total - failedWeeks.length}/${total} tuần. Mới: ${uniqueNewEvents.length} • Tổng: ${merged.length}${failMsg}${skipMsg}`;
    const statusText = `Xong: ${total - failedWeeks.length}/${total} tuần. Tiết mới: ${uniqueNewEvents.length}.${failedWeeks.length ? " Có tuần lỗi (xem toast)." : ""}`;

    chrome.storage.local.set(
      {
        classSchedule: mergedJson,
        weekRangeSyncRunning: false,
        weekRangeProgress: null,
        weekRangeLastSummary: { toastText, statusText }
      },
      () => {
        rescheduleAllAlarms();
        notifyScheduleChanges(scheduleChanges);
        chrome.runtime
          .sendMessage({
            type: "WEEK_RANGE_SYNC_DONE",
            mergedJson,
            toastText,
            statusText,
            uniqueNewCount: uniqueNewEvents.length,
            totalWeeks: total,
            failedCount: failedWeeks.length
          })
          .catch(() => {});
        onComplete && onComplete(null, { mergedJson, uniqueNewEvents, failedWeeks });
      }
    );
  }

  function stepModern() {
    if (current > hi) {
      finish();
      return;
    }
    const idx = current;
    const weekMeta = (weeksMeta && weeksMeta[idx]) || null;
    const label = labelForWeek(idx);

    chrome.storage.local.set({
      weekRangeProgress: { current: stepIndex + 1, total, label }
    });
    chrome.runtime
      .sendMessage({
        type: "WEEK_RANGE_PROGRESS",
        current: stepIndex + 1,
        total,
        label
      })
      .catch(() => {});

    chrome.scripting.executeScript(
      { target: { tabId }, files: ["content.js"] },
      () => {
        chrome.tabs.sendMessage(
          tabId,
          {
            action: "fetchAndExtractWeekSchedule",
            weekIndex: idx,
            weekMeta
          },
          (response) => {
            const err = chrome.runtime.lastError;
            if (err || !response || !response.success) {
              if (response && response.loginRequired) {
                failedWeeks.push({ index: idx, label, reason: "login" });
                chrome.storage.local.set({ weekRangeSyncRunning: false, weekRangeProgress: null }, () => {
                  chrome.tabs.create({ url: "https://fap.fpt.edu.vn/Default.aspx", active: true });
                  chrome.runtime
                    .sendMessage({ type: "WEEK_RANGE_SYNC_ERROR", message: "login" })
                    .catch(() => {});
                });
                onComplete && onComplete(new Error("login"));
                return;
              }
              failedWeeks.push({ index: idx, label, reason: (err && err.message) || (response && response.error) || "fetch-failed" });
            } else {
              collected.push.apply(collected, response.schedule || []);
              skippedCells += response.skipped || 0;
            }
            stepIndex += 1;
            current += 1;
            setTimeout(stepModern, 120);
          }
        );
      }
    );
  }

  function stepLegacy() {
    if (current > hi) {
      finish();
      return;
    }
    const idx = current;
    const label = labelForWeek(idx);
    chrome.storage.local.set({
      weekRangeProgress: { current: stepIndex + 1, total, label }
    });
    chrome.runtime
      .sendMessage({
        type: "WEEK_RANGE_PROGRESS",
        current: stepIndex + 1,
        total,
        label
      })
      .catch(() => {});

    const cancelWait = armWaitForTabComplete(tabId, 28000, (loadOk) => {
      if (!loadOk) {
        failedWeeks.push({ index: idx, label, reason: "timeout" });
        stepIndex += 1;
        current += 1;
        stepLegacy();
        return;
      }
      extractWeeklyScheduleFromTab(tabId, (err, response) => {
        if (err || !response || !response.success) {
          if (response && response.loginRequired) {
            failedWeeks.push({ index: idx, label, reason: "login" });
            chrome.storage.local.set({ weekRangeSyncRunning: false, weekRangeProgress: null }, () => {
              chrome.tabs.create({ url: "https://fap.fpt.edu.vn/Default.aspx", active: true });
              chrome.runtime
                .sendMessage({ type: "WEEK_RANGE_SYNC_ERROR", message: "login" })
                .catch(() => {});
            });
            onComplete && onComplete(new Error("login"));
            return;
          }
          failedWeeks.push({ index: idx, label, reason: err || "extract" });
        } else {
          collected.push.apply(collected, response.schedule || []);
          skippedCells += response.skipped || 0;
        }
        stepIndex += 1;
        current += 1;
        stepLegacy();
      });
    });

    executeFapWeekIndexMain(tabId, idx, (err, result) => {
      if (err) {
        cancelWait();
        failedWeeks.push({ index: idx, label, reason: err });
        stepIndex += 1;
        current += 1;
        stepLegacy();
        return;
      }
      if (result.skippedPostback) {
        cancelWait();
        extractWeeklyScheduleFromTab(tabId, (e2, response) => {
          if (e2 || !response || !response.success) {
            failedWeeks.push({ index: idx, label, reason: e2 || "extract" });
          } else {
            collected.push.apply(collected, response.schedule || []);
            skippedCells += response.skipped || 0;
          }
          stepIndex += 1;
          current += 1;
          stepLegacy();
        });
        return;
      }
    });
  }

  if (isNewUi) {
    stepModern();
  } else {
    stepLegacy();
  }
}

function readNotificationSettings(callback) {
  chrome.storage.local.get(["notificationSettings"], (res) => {
    const base = typeof DEFAULT_NOTIFICATION_SETTINGS !== "undefined" ? DEFAULT_NOTIFICATION_SETTINGS : { enabled: true };
    callback((res && res.notificationSettings) || base);
  });
}

/** Tell the student about room/time changes, cancellations and new classes found by a sync. */
function notifyScheduleChanges(changes) {
  if (!Array.isArray(changes) || changes.length === 0) return;
  if (typeof formatScheduleChangeNotifications !== "function" || !chrome.notifications) return;
  readNotificationSettings((settings) => {
    if (!settings || settings.enabled === false) return;
    if (settings.changes && settings.changes.enabled === false) return;
    formatScheduleChangeNotifications(changes).forEach((n) => {
      chrome.notifications.create(n.id, {
        type: "basic",
        iconUrl: n.iconUrl || "icon-128.png",
        title: n.title,
        message: n.message,
        priority: 2
      }, () => {
        if (chrome.runtime.lastError) console.warn("background: change notification failed", chrome.runtime.lastError.message);
      });
    });
  });
}

// Chrome does not guarantee alarms survive a browser restart or an extension update, and the
// popup is the only other thing that re-arms them. Re-arm on every startup/install, and keep a
// daily alarm (named without the "fptu:" prefix so rescheduleAllAlarms never clears it).
const MAINTENANCE_ALARM = "fptu-refresh";
// Wakes the worker when the toolbar badge count should change (a class ends, or midnight).
const BADGE_ALARM = "fptu-badge";
const BADGE_BACKGROUND = "#1e293b";

function swallow(result) {
  if (result && typeof result.catch === "function") result.catch(() => {});
}

/** Show today's remaining classes on the toolbar icon and arm the alarm for its next change. */
function updateActionBadge(classEvents, settings, now = new Date()) {
  if (!chrome.action || typeof computeTodayBadge !== "function") return;
  const enabled = !(settings && settings.badge && settings.badge.enabled === false);
  let text = "";
  if (enabled) {
    const { count, nextChangeAt } = computeTodayBadge(classEvents, now);
    text = count > 99 ? "99+" : count > 0 ? String(count) : "";
    if (chrome.alarms) chrome.alarms.create(BADGE_ALARM, { when: nextChangeAt });
  } else if (chrome.alarms) {
    chrome.alarms.clear(BADGE_ALARM);
  }
  try {
    swallow(chrome.action.setBadgeText({ text }));
    if (text) {
      swallow(chrome.action.setBadgeBackgroundColor({ color: BADGE_BACKGROUND }));
      if (chrome.action.setBadgeTextColor) swallow(chrome.action.setBadgeTextColor({ color: "#ffffff" }));
    }
  } catch (_) {}
}

function ensureMaintenanceAlarm() {
  if (!chrome.alarms) return;
  chrome.alarms.get(MAINTENANCE_ALARM, (existing) => {
    if (!existing) chrome.alarms.create(MAINTENANCE_ALARM, { delayInMinutes: 5, periodInMinutes: 24 * 60 });
  });
}

function bootstrapAlarms() {
  rescheduleAllAlarms();
  ensureMaintenanceAlarm();
}

if (chrome.runtime && chrome.runtime.onInstalled) chrome.runtime.onInstalled.addListener(bootstrapAlarms);
if (chrome.runtime && chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(bootstrapAlarms);

function rescheduleAllAlarms(callback) {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local || !chrome.alarms) {
    callback && callback();
    return;
  }

  chrome.storage.local.get(["classSchedule", "examSchedule", "notificationSettings"], (res) => {
    if (chrome.runtime.lastError) {
      callback && callback();
      return;
    }

    let settings = res.notificationSettings;
    if (!settings) {
      settings = typeof DEFAULT_NOTIFICATION_SETTINGS !== "undefined"
        ? DEFAULT_NOTIFICATION_SETTINGS
        : { enabled: true, class: { enabled: true, offset15: true, offset30: false }, exam: { enabled: true, offset1Day: true, offset1Hour: true } };
    }

    let classEvents = [];
    try {
      classEvents = JSON.parse(res.classSchedule || "[]");
    } catch (_) {}

    let examEvents = [];
    try {
      examEvents = JSON.parse(res.examSchedule || "[]");
    } catch (_) {}

    const now = new Date();
    updateActionBadge(classEvents, settings, now);
    const classAlarms = typeof buildClassAlarmItems === "function"
      ? buildClassAlarmItems(classEvents, settings, now)
      : [];
    const examAlarms = typeof buildExamAlarmItems === "function"
      ? buildExamAlarmItems(examEvents, settings, now)
      : [];

    const allAlarms = classAlarms.concat(examAlarms);
    const alarmMetadata = {};

    chrome.alarms.getAll((existing) => {
      const fptuAlarms = (existing || []).filter((a) => a && a.name && a.name.startsWith("fptu:"));
      const clearPromises = fptuAlarms.map((a) => new Promise((resolve) => chrome.alarms.clear(a.name, resolve)));

      Promise.all(clearPromises).then(() => {
        if (!settings.enabled) {
          chrome.storage.local.set({ activeAlarmsMetadata: {} }, () => callback && callback());
          return;
        }

        allAlarms.forEach((item) => {
          alarmMetadata[item.name] = item;
          chrome.alarms.create(item.name, { when: item.when });
        });

        chrome.storage.local.set({ activeAlarmsMetadata: alarmMetadata }, () => callback && callback());
      });
    });
  });
}

if (typeof chrome !== "undefined" && chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm && (alarm.name === MAINTENANCE_ALARM || alarm.name === BADGE_ALARM)) {
      rescheduleAllAlarms();
      return;
    }
    if (!alarm || !alarm.name || !alarm.name.startsWith("fptu:")) return;

    chrome.storage.local.get(["activeAlarmsMetadata"], (res) => {
      const meta = (res && res.activeAlarmsMetadata) || {};
      const item = meta[alarm.name] || (typeof parseAlarmName === "function" ? parseAlarmName(alarm.name) : null);
      const details = typeof formatNotificationDetails === "function"
        ? formatNotificationDetails(item)
        : { title: "FPTU Schedule", message: "Bạn có lịch học / lịch thi sắp diễn ra.", iconUrl: "icon-128.png" };

      if (typeof chrome.notifications !== "undefined" && chrome.notifications.create) {
        chrome.notifications.create(alarm.name, {
          type: "basic",
          iconUrl: details.iconUrl || "icon-128.png",
          title: details.title || "FPTU Schedule",
          message: details.message || "Bạn có lịch sắp tới.",
          priority: 2
        });
      }
    });
  });
}

if (typeof chrome !== "undefined" && chrome.notifications && chrome.notifications.onClicked) {
  chrome.notifications.onClicked.addListener((notificationId) => {
    if (!notificationId || !notificationId.startsWith("fptu:")) return;
    const isExam = notificationId.startsWith("fptu:exam:");
    const targetUrl = isExam
      ? "https://fap.fpt.edu.vn/ExamSchedule"
      : "https://fap.fpt.edu.vn/WeeklyTimetable";

    chrome.tabs.query({ url: "*://fap.fpt.edu.vn/*" }, (tabs) => {
      const matchingTab = (tabs || []).find((t) =>
        t.url && (isExam
          ? (t.url.includes("ExamSchedule") || t.url.includes("ScheduleExams"))
          : (t.url.includes("WeeklyTimetable") || t.url.includes("ScheduleOfWeek")))
      );
      if (matchingTab && matchingTab.id) {
        chrome.tabs.update(matchingTab.id, { active: true });
      } else {
        chrome.tabs.create({ url: targetUrl, active: true });
      }
      chrome.notifications.clear(notificationId);
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;

  if (msg.type === "RESCHEDULE_ALARMS") {
    rescheduleAllAlarms(() => sendResponse && sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "TEST_NOTIFICATION") {
    if (!chrome.notifications || !chrome.notifications.create) {
      sendResponse && sendResponse({ ok: false, reason: "unavailable" });
      return false;
    }
    const send = (level) => {
      if (level === "denied") {
        sendResponse && sendResponse({ ok: false, reason: "denied" });
        return;
      }
      chrome.notifications.create("fptu:test:" + Date.now(), {
        type: "basic",
        iconUrl: "icon-128.png",
        title: "[FPTU Schedule] Thông báo thử nghiệm",
        message: "Hệ thống thông báo hoạt động tốt! Bạn sẽ nhận được nhắc nhở trước giờ học và giờ thi.",
        priority: 2
      }, () => {
        const err = chrome.runtime.lastError;
        sendResponse && sendResponse(err ? { ok: false, reason: "error", message: err.message } : { ok: true });
      });
    };
    if (typeof chrome.notifications.getPermissionLevel === "function") {
      chrome.notifications.getPermissionLevel((level) => send(level));
    } else {
      send("granted");
    }
    return true;
  }

  if (msg.type === "SCHEDULE_CHANGES") {
    notifyScheduleChanges(msg.changes);
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "GET_ALARM_SUMMARY") {
    chrome.alarms.getAll((all) => {
      const mine = (all || []).filter((a) => a && a.name && a.name.startsWith("fptu:"));
      const next = mine.reduce((min, a) => (min === null || a.scheduledTime < min ? a.scheduledTime : min), null);
      sendResponse && sendResponse({ count: mine.length, nextTime: next });
    });
    return true;
  }

  if (msg.type === "SAVE_WEEK_SCHEDULE") {
    if (!Array.isArray(msg.schedule) || msg.schedule.length === 0) {
      sendResponse && sendResponse({ ok: false, changed: false });
      return false;
    }
    chrome.storage.local.get(["classSchedule", "weekRangeSyncRunning"], (res) => {
      // A multi-week sync owns the schedule while it runs; it reports its own changes.
      if (res && res.weekRangeSyncRunning) {
        sendResponse && sendResponse({ ok: true, changed: false, reason: "sync-running" });
        return;
      }
      const out = applyWeekCapture(res && res.classSchedule, msg.schedule, msg.skipped || 0, new Date());
      if (!out.changed) {
        sendResponse && sendResponse({ ok: true, changed: false });
        return;
      }
      chrome.storage.local.set({ classSchedule: out.mergedJson }, () => {
        rescheduleAllAlarms();
        notifyScheduleChanges(out.changes);
        sendResponse && sendResponse({ ok: true, changed: true, changes: out.changes.length });
      });
    });
    return true;
  }

  if (msg.type === "SAVE_STUDENT_GRADE" && msg.grade && msg.grade.courseCode) {
    chrome.storage.local.get(["studentGrades"], (res) => {
      const map = (res && res.studentGrades) || {};
      map[msg.grade.courseCode] = msg.grade;
      chrome.storage.local.set({ studentGrades: map }, () => {
        sendResponse && sendResponse({ ok: true, count: Object.keys(map).length });
      });
    });
    return true;
  }

  if (msg.type === "START_ALL_GRADES_SYNC") {
    const { tabId, totalCourses } = msg;
    if (tabId == null || !totalCourses) {
      sendResponse && sendResponse({ ok: false, error: "bad-payload" });
      return false;
    }
    runAllGradesSync(tabId, totalCourses, (err, map) => {
      /* done handled by runner */
    });
    sendResponse && sendResponse({ ok: true });
    return false;
  }

  if (msg.type !== "START_WEEK_RANGE_SYNC") {
    return false;
  }

  const { tabId, startIdx, endIdx, weekLabels, seedJson, isNewUi, weeksMeta } = msg;
  if (tabId == null || startIdx == null || endIdx == null) {
    sendResponse({ ok: false, error: "bad-payload" });
    return false;
  }

  const seed =
    typeof seedJson === "string" ? seedJson : JSON.stringify([]);

  chrome.storage.local.set({ weekRangeSyncRunning: true }, () => {
    chrome.tabs.get(tabId, (tab) => {
      const effectiveIsNewUi = Boolean(isNewUi) || (tab && tab.url && /WeeklyTimetable/i.test(tab.url));
      runWeekRangeSync(tabId, startIdx, endIdx, weekLabels || [], seed, effectiveIsNewUi, weeksMeta || null, (err) => {
        if (err && err.message === "login") {
          /* already notified */
        } else if (err) {
          chrome.storage.local.set({ weekRangeSyncRunning: false });
        }
      });
    });
  });

  sendResponse({ ok: true });
  return false;
});

function executeFapCourseIndexMain(tabId, courseIndex, callback) {
  chrome.scripting.executeScript(
    {
      target: { tabId },
      world: "MAIN",
      func: (idx) => {
        const sel =
          document.getElementById("ctl00_mainContent_drpCourse") ||
          document.getElementById("ctl00_mainContent_ddlCourse") ||
          document.querySelector('select[id*="mainContent"][id*="Course"]') ||
          document.querySelector('select[name*="Course"]');
        if (!sel) return { ok: false, error: "course-select-not-found" };
        if (idx < 0 || idx >= sel.options.length) return { ok: false, error: "bad-index" };
        if (sel.selectedIndex === idx) {
          return { ok: true, skippedPostback: true };
        }
        sel.selectedIndex = idx;
        const oc = sel.getAttribute("onchange") || "";
        const m = oc.match(/__doPostBack\s*\(\s*'([^']*)'\s*,\s*'([^']*)'\s*\)/);
        if (typeof __doPostBack === "function") {
          if (m) __doPostBack(m[1], m[2] !== undefined && m[2] !== null ? m[2] : "");
          else __doPostBack(sel.name, "");
          return { ok: true, skippedPostback: false };
        }
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true, skippedPostback: false, weak: true };
      },
      args: [courseIndex]
    },
    (results) => {
      if (chrome.runtime.lastError) {
        callback(chrome.runtime.lastError.message, null);
        return;
      }
      const r = results && results[0] && results[0].result;
      if (!r || !r.ok) {
        callback((r && r.error) || "unknown", null);
        return;
      }
      callback(null, r);
    }
  );
}

function extractGradeFromTab(tabId, callback) {
  chrome.scripting.executeScript({ target: { tabId }, files: ["lib/grades.js", "content.js"] }, () => {
    if (chrome.runtime.lastError) {
      callback(chrome.runtime.lastError.message, null);
      return;
    }
    chrome.tabs.sendMessage(tabId, { action: "extractStudentGrade" }, (response) => {
      if (chrome.runtime.lastError) {
        callback(chrome.runtime.lastError.message, null);
        return;
      }
      callback(null, response);
    });
  });
}

function runAllGradesSync(tabId, totalCourses, onComplete) {
  let current = 0;
  let savedCount = 0;

  function step() {
    if (current >= totalCourses) {
      chrome.storage.local.get(["studentGrades"], (res) => {
        const map = (res && res.studentGrades) || {};
        chrome.runtime.sendMessage({
          type: "ALL_GRADES_SYNC_DONE",
          total: totalCourses,
          savedCount
        }).catch(() => {});
        onComplete && onComplete(null, map);
      });
      return;
    }

    const idx = current;
    const cancelWait = armWaitForTabComplete(tabId, 25000, (loadOk) => {
      if (!loadOk) {
        current += 1;
        step();
        return;
      }
      extractGradeFromTab(tabId, (err, resp) => {
        if (!err && resp && resp.ok && resp.grade) {
          chrome.storage.local.get(["studentGrades"], (res) => {
            const map = (res && res.studentGrades) || {};
            map[resp.grade.courseCode] = resp.grade;
            savedCount += 1;
            chrome.storage.local.set({ studentGrades: map }, () => {
              current += 1;
              step();
            });
          });
        } else {
          current += 1;
          step();
        }
      });
    });

    executeFapCourseIndexMain(tabId, idx, (err, result) => {
      if (err) {
        cancelWait();
        current += 1;
        step();
        return;
      }
      if (result && result.skippedPostback) {
        cancelWait();
        extractGradeFromTab(tabId, (err2, resp) => {
          if (!err2 && resp && resp.ok && resp.grade) {
            chrome.storage.local.get(["studentGrades"], (res) => {
              const map = (res && res.studentGrades) || {};
              map[resp.grade.courseCode] = resp.grade;
              savedCount += 1;
              chrome.storage.local.set({ studentGrades: map }, () => {
                current += 1;
                step();
              });
            });
          } else {
            current += 1;
            step();
          }
        });
      }
    });
  }

  step();
}
